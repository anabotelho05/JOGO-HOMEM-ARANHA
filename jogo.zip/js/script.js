// =============================================================================
// Web Swing Survival — script.js
// Totalmente responsivo para notebooks e telas de qualquer resolução
// =============================================================================

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const PlayerState = Object.freeze({
    IDLE:         'IDLE',
    RUNNING:      'RUNNING',
    JUMPING:      'JUMPING',
    FALLING:      'FALLING',
    WEB_SHOOTING: 'WEB_SHOOTING',
    SWINGING:     'SWINGING',
    HIT:          'HIT',
    GAME_OVER:    'GAME_OVER',
});

const GameMode = Object.freeze({
    SOLO:  'SOLO',
    DUPLA: 'DUPLA',
});

const DIFFICULTY_TIERS = [
    { name: 'Easy',    scoreMin: 0,    scrollSpeed: 3.0, spawnInterval: 4200 },
    { name: 'Medium',  scoreMin: 1500, scrollSpeed: 4.2, spawnInterval: 3000 },
    { name: 'Hard',    scoreMin: 4000, scrollSpeed: 5.4, spawnInterval: 2000 },
    { name: 'Extreme', scoreMin: 8000, scrollSpeed: 6.8, spawnInterval: 1300 },
];

// ---------------------------------------------------------------------------
// Helper functions
// ---------------------------------------------------------------------------

function safeLSGet(key, fallback) {
    try {
        const val = localStorage.getItem(key);
        return val !== null ? val : fallback;
    } catch { return fallback; }
}

function safeLSSet(key, value) {
    try { localStorage.setItem(key, value); } catch {}
}

function getTierForScore(score) {
    let tier = DIFFICULTY_TIERS[0];
    for (const t of DIFFICULTY_TIERS) { if (score >= t.scoreMin) tier = t; }
    return tier;
}

// ---------------------------------------------------------------------------
// Cálculo dinâmico da altura máxima real alcançável (Pulo + Balanço de Teia)
// ---------------------------------------------------------------------------

function getMaxReachableHeight(groundY) {
    // A altura real máxima que a teia e o pulo atingem é proporcional ao teto útil do cenário
    // permitindo que o arco acompanhe até o ápice do balanço sem tetos artificiais fixos
    return Math.max(90, groundY - 45);
}

function getCoinHeightRange(groundY) {
    const maxReach    = getMaxReachableHeight(groundY);
    const maxCoinRelY = maxReach * 0.85; // ~85% da altura máxima real alcançável
    const minCoinRelY = 24;              // nível do chão
    return { minRelY: minCoinRelY, maxRelY: maxCoinRelY, maxReach };
}

// ---------------------------------------------------------------------------
// Input — gerenciamento de teclado e mouse com suporte a P1 (WASD) e P2 (Setas)
// ---------------------------------------------------------------------------

class Input {
    constructor(canvas) {
        this.canvas   = canvas;
        this.swingBtn = document.getElementById('swingBtn');

        // Mapa de teclas ativas
        this._keys = {};

        // Flags de frame único
        this._keysDown = new Set();
        this._keysUp   = new Set();

        // P1 flags
        this._p1WDown = false;
        this._p1WUp   = false;

        // P2 flags
        this._p2UpDown = false;
        this._p2UpUp   = false;

        // Solo flags
        this._soloUpDown = false;
        this._soloUpUp   = false;
        this._spaceDown  = false;
        this._spaceUp    = false;

        this.gameActive = false;

        // Mouse
        this.mouseX = 640;
        this.mouseY = 360;
        this._mouseDown = false;
        this._mouseUp   = false;
        this._mouseHeld = false;

        // Públicos por frame
        this.mouseJustDown = false;
        this.mouseJustUp   = false;
        this.mouseHeld     = false;

        // P1 (WASD)
        this.p1 = { left: false, right: false, up: false, down: false,
                    jumpJustPressed: false, jumpJustReleased: false,
                    webJustPressed: false,  webJustReleased: false };

        // P2 (Setas)
        this.p2 = { left: false, right: false, up: false, down: false,
                    jumpJustPressed: false, jumpJustReleased: false,
                    webJustPressed: false,  webJustReleased: false };

        // Solo (Setas + Espaço)
        this.solo = { left: false, right: false, up: false, down: false,
                      jumpJustPressed: false, jumpJustReleased: false,
                      webJustPressed: false,  webJustReleased: false, spaceHeld: false };

        this._onKeyDown = this._handleKeyDown.bind(this);
        this._onKeyUp   = this._handleKeyUp.bind(this);
        this._onMouseDown = this._handleMouseDown.bind(this);
        this._onMouseUp   = this._handleMouseUp.bind(this);
        this._onMouseMove = this._handleMouseMove.bind(this);
        this._onBtnTouchStart = this._handleBtnTouchStart.bind(this);
        this._onBtnTouchEnd   = this._handleBtnTouchEnd.bind(this);
        this._onCanvasTouchStart = (e) => e.preventDefault();
        this._onCanvasTouchMove  = (e) => e.preventDefault();

        this._bindEvents();
    }

    _bindEvents() {
        window.addEventListener('keydown', this._onKeyDown);
        window.addEventListener('keyup',   this._onKeyUp);
        this.canvas.addEventListener('mousedown', this._onMouseDown);
        this.canvas.addEventListener('mouseup',   this._onMouseUp);
        this.canvas.addEventListener('mousemove', this._onMouseMove);
        if (this.swingBtn) {
            this.swingBtn.addEventListener('touchstart', this._onBtnTouchStart, { passive: false });
            this.swingBtn.addEventListener('touchend',   this._onBtnTouchEnd,   { passive: false });
        }
        this.canvas.addEventListener('touchstart', this._onCanvasTouchStart, { passive: false });
        this.canvas.addEventListener('touchmove',  this._onCanvasTouchMove,  { passive: false });
    }

    _toCanvas(clientX, clientY) {
        const rect = this.canvas.getBoundingClientRect();
        return {
            x: (clientX - rect.left) * (this.canvas.width / rect.width),
            y: (clientY - rect.top)  * (this.canvas.height / rect.height)
        };
    }

    _handleKeyDown(e) {
        const code = e.code;
        if (this.gameActive) {
            const prevent = ['Space','KeyW','KeyA','KeyS','KeyD',
                             'ArrowUp','ArrowDown','ArrowLeft','ArrowRight'];
            if (prevent.includes(code)) e.preventDefault();
        }

        if (this._keys[code]) return; // já pressionada
        this._keys[code] = true;
        this._keysDown.add(code);

        if (code === 'KeyW')       this._p1WDown    = true;
        if (code === 'ArrowUp')    { this._p2UpDown = true; this._soloUpDown = true; }
        if (code === 'Space')      this._spaceDown  = true;
    }

    _handleKeyUp(e) {
        const code = e.code;
        this._keys[code] = false;
        this._keysUp.add(code);

        if (code === 'KeyW')       this._p1WUp    = true;
        if (code === 'ArrowUp')    { this._p2UpUp = true; this._soloUpUp = true; }
        if (code === 'Space')      this._spaceUp  = true;
    }

    _handleMouseDown(e) {
        e.preventDefault();
        const pos = this._toCanvas(e.clientX, e.clientY);
        this.mouseX = pos.x;
        this.mouseY = pos.y;
        this._mouseDown = true;
        this._mouseHeld = true;
    }

    _handleMouseUp(e) {
        e.preventDefault();
        this._mouseUp = true;
        this._mouseHeld = false;
    }

    _handleMouseMove(e) {
        const pos = this._toCanvas(e.clientX, e.clientY);
        this.mouseX = pos.x;
        this.mouseY = pos.y;
    }

    _handleBtnTouchStart(e) {
        e.preventDefault();
        this._spaceDown = true;
        this._mouseHeld = true;
    }

    _handleBtnTouchEnd(e) {
        e.preventDefault();
        this._spaceUp = true;
        this._mouseHeld = false;
    }

    processFrame() {
        this.mouseJustDown = this._mouseDown;
        this.mouseJustUp   = this._mouseUp;
        this.mouseHeld     = this._mouseHeld;
        this._mouseDown    = false;
        this._mouseUp      = false;

        // P1 (WASD)
        this.p1.left  = !!this._keys['KeyA'];
        this.p1.right = !!this._keys['KeyD'];
        this.p1.up    = !!this._keys['KeyW'];
        this.p1.down  = !!this._keys['KeyS'];
        this.p1.jumpJustPressed  = this._p1WDown;
        this.p1.jumpJustReleased = this._p1WUp;

        // P2 (Setas)
        this.p2.left  = !!this._keys['ArrowLeft'];
        this.p2.right = !!this._keys['ArrowRight'];
        this.p2.up    = !!this._keys['ArrowUp'];
        this.p2.down  = !!this._keys['ArrowDown'];
        this.p2.jumpJustPressed  = this._p2UpDown;
        this.p2.jumpJustReleased = this._p2UpUp;

        // Solo (Setas + Espaço)
        this.solo.left  = !!this._keys['ArrowLeft'];
        this.solo.right = !!this._keys['ArrowRight'];
        this.solo.up    = !!this._keys['ArrowUp'];
        this.solo.down  = !!this._keys['ArrowDown'];
        this.solo.spaceHeld = !!this._keys['Space'] || this.mouseHeld;
        this.solo.jumpJustPressed  = this._soloUpDown;
        this.solo.jumpJustReleased = this._soloUpUp;

        // Reset flags de frame único
        this._p1WDown    = false; this._p1WUp    = false;
        this._p2UpDown   = false; this._p2UpUp   = false;
        this._soloUpDown = false; this._soloUpUp = false;
        this._spaceDown  = false; this._spaceUp  = false;
        this._keysDown.clear();
        this._keysUp.clear();
    }

    setGameActive(active) { this.gameActive = active; }

    destroy() {
        window.removeEventListener('keydown', this._onKeyDown);
        window.removeEventListener('keyup',   this._onKeyUp);
        this.canvas.removeEventListener('mousedown', this._onMouseDown);
        this.canvas.removeEventListener('mouseup',   this._onMouseUp);
        this.canvas.removeEventListener('mousemove', this._onMouseMove);
        if (this.swingBtn) {
            this.swingBtn.removeEventListener('touchstart', this._onBtnTouchStart);
            this.swingBtn.removeEventListener('touchend',   this._onBtnTouchEnd);
        }
    }
}

// ---------------------------------------------------------------------------
// AudioSystem
// ---------------------------------------------------------------------------

class AudioSystem {
    constructor() {
        this._slots = new Map();
        this._muted = safeLSGet('webSwingMuted', 'false') === 'true';
    }
    load(slots) {
        for (const { name, path } of slots) {
            try {
                const el = new window.Audio(path);
                el.onerror = () => this._slots.delete(name);
                this._slots.set(name, el);
            } catch(e) {}
        }
    }
    play(name) {
        if (this._muted) return;
        const el = this._slots.get(name);
        if (!el) return;
        try { const c = el.cloneNode(); c.volume = 0.4; c.play().catch(() => {}); } catch(e) {}
    }
    playCoin() {
        if (this._muted) return;
        try {
            const ctx = this._audioCtx || (this._audioCtx = new (window.AudioContext || window.webkitAudioContext)());
            if (ctx.state === 'suspended') ctx.resume();
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(987.77, now); // Si 5 (B5)
            osc.frequency.setValueAtTime(1318.51, now + 0.07); // Mi 6 (E6)
            gain.gain.setValueAtTime(0.25, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.32);
        } catch(e) {}
    }
    playTransformation() {
        if (this._muted) return;
        try {
            const ctx = this._audioCtx || (this._audioCtx = new (window.AudioContext || window.webkitAudioContext)());
            if (ctx.state === 'suspended') ctx.resume();
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(220, now);
            osc.frequency.exponentialRampToValueAtTime(780, now + 0.28);
            gain.gain.setValueAtTime(0.3, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.35);
        } catch(e) {}
    }
    toggleMute() { this._muted = !this._muted; safeLSSet('webSwingMuted', this._muted); }
    get isMuted() { return this._muted; }
}

// ---------------------------------------------------------------------------
// Background — renderização dinâmica que preenche 100% da largura em qualquer tela
// ---------------------------------------------------------------------------

class Background {
    constructor() {
        this.offsetX = 0;
        this.layers = [
            { multiplier: 0.1, offsetX: 0 }, // Céu / Nuvens
            { multiplier: 0.3, offsetX: 0 }, // Prédios distantes
            { multiplier: 0.6, offsetX: 0 }, // Prédios próximos
            { multiplier: 1.0, offsetX: 0 }, // Rua / Postes
            { multiplier: 1.0, offsetX: 0 }, // Obstáculos
        ];
        this._initBuildingSpecs();
    }

    _initBuildingSpecs() {
        // Modelos de prédios de fundo
        this.distantSpecs = [
            { w: 65, h: 320, color: '#181838' },
            { w: 55, h: 280, color: '#1c1c42' },
            { w: 75, h: 370, color: '#1a1a3e' },
            { w: 60, h: 240, color: '#202048' },
            { w: 55, h: 310, color: '#181838' },
            { w: 70, h: 350, color: '#1c1c44' },
            { w: 60, h: 260, color: '#1a1a40' },
            { w: 68, h: 380, color: '#181838' },
            { w: 58, h: 290, color: '#20204c' },
            { w: 72, h: 340, color: '#1a1a3e' },
        ];
        this.distantTileW = this.distantSpecs.reduce((acc, b) => acc + b.w + 40, 0);

        // Modelos de prédios de primeiro plano
        this.closeSpecs = [
            { w: 100, h: 280, color: '#2a2a5a' },
            { w: 120, h: 240, color: '#2e2e62' },
            { w:  95, h: 300, color: '#2c2c5e' },
            { w: 130, h: 200, color: '#303068' },
            { w: 110, h: 260, color: '#2a2a5a' },
            { w: 115, h: 220, color: '#2e2e64' },
            { w: 100, h: 290, color: '#2c2c60' },
        ];
        this.closeTileW = this.closeSpecs.reduce((acc, b) => acc + b.w + 50, 0);

        // Nuvens
        this.clouds = [
            { x: 100,  y: 60,  rx: 90, ry: 20 },
            { x: 450,  y: 95,  rx: 75, ry: 18 },
            { x: 820,  y: 50,  rx: 110, ry: 22 },
            { x: 1200, y: 80,  rx: 85, ry: 16 },
            { x: 1550, y: 65,  rx: 95, ry: 20 },
        ];
        this.cloudTileW = 1800;

        // Estrelas fixas no céu
        this.stars = [];
        for (let i = 0; i < 70; i++) {
            this.stars.push({
                xRatio: (i * 37 + 13) % 100 / 100,
                yRatio: (i * 23 + 7)  % 100 / 100
            });
        }
    }

    update(scrollSpeed, dt) {
        const pxPerSec = scrollSpeed * 60;
        const delta    = pxPerSec * (dt / 1000);
        for (const layer of this.layers) {
            layer.offsetX += delta * layer.multiplier;
        }
    }

    draw(ctx, width, height, groundY) {
        this._drawSky(ctx, width, height, groundY);
        this._drawDistantBuildings(ctx, width, height, groundY);
        this._drawCloseBuildings(ctx, width, height, groundY);
        this._drawStreet(ctx, width, height, groundY);
        this._drawObstacles(ctx, width, height, groundY);
    }

    _drawSky(ctx, width, height, groundY) {
        // Fundo do céu noturno com gradiente suave
        const skyGrad = ctx.createLinearGradient(0, 0, 0, groundY);
        skyGrad.addColorStop(0, '#060614');
        skyGrad.addColorStop(1, '#101026');
        ctx.fillStyle = skyGrad;
        ctx.fillRect(0, 0, width, height);

        // Estrelas
        ctx.fillStyle = '#ffffff';
        for (const s of this.stars) {
            const sx = s.xRatio * width;
            const sy = s.yRatio * Math.max(100, groundY * 0.55);
            ctx.fillRect(sx, sy, 1.5, 1.5);
        }

        // Lua
        const moonX = width - Math.min(140, width * 0.15);
        const moonY = Math.min(75, height * 0.18);
        const moonR = Math.min(28, Math.max(18, height * 0.05));
        ctx.fillStyle = '#fffde8';
        ctx.beginPath();
        ctx.arc(moonX, moonY, moonR, 0, Math.PI * 2);
        ctx.fill();

        // Brilho da lua
        ctx.fillStyle = 'rgba(255, 253, 232, 0.12)';
        ctx.beginPath();
        ctx.arc(moonX, moonY, moonR * 1.6, 0, Math.PI * 2);
        ctx.fill();

        // Nuvens com repetição contínua por toda a largura
        ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
        const cloudOff = this.layers[0].offsetX % this.cloudTileW;
        const cloudRepeat = Math.ceil(width / this.cloudTileW) + 2;
        for (let r = 0; r < cloudRepeat; r++) {
            const shift = r * this.cloudTileW - cloudOff;
            for (const c of this.clouds) {
                const cx = c.x + shift;
                if (cx + c.rx < -50 || cx - c.rx > width + 50) continue;
                ctx.beginPath();
                ctx.ellipse(cx, c.y * (groundY / 600), c.rx, c.ry, 0, 0, Math.PI * 2);
                ctx.fill();
            }
        }
    }

    _drawDistantBuildings(ctx, width, height, groundY) {
        const off = this.layers[1].offsetX % this.distantTileW;
        const repeat = Math.ceil(width / this.distantTileW) + 2;

        for (let r = 0; r < repeat; r++) {
            let curX = r * this.distantTileW - off;
            for (let i = 0; i < this.distantSpecs.length; i++) {
                const b = this.distantSpecs[i];
                const bx = curX;
                const bw = b.w;
                const bh = b.h * (groundY / 600);
                const by = groundY - bh;
                curX += bw + 40;

                if (bx + bw < 0 || bx > width) continue;

                ctx.fillStyle = b.color;
                ctx.fillRect(bx, by, bw, bh);

                // Janelas iluminadas
                ctx.globalAlpha = 0.55;
                ctx.fillStyle = '#ffff88';
                for (let wy = by + 16; wy < groundY - 14; wy += 20) {
                    for (let wx = bx + 6; wx < bx + bw - 8; wx += 13) {
                        if ((wx + wy) % 3 !== 0) {
                            ctx.fillRect(wx, wy, 3.5, 3.5);
                        }
                    }
                }
                ctx.globalAlpha = 1.0;
            }
        }
    }

    _drawCloseBuildings(ctx, width, height, groundY) {
        const off = this.layers[2].offsetX % this.closeTileW;
        const repeat = Math.ceil(width / this.closeTileW) + 2;

        for (let r = 0; r < repeat; r++) {
            let curX = r * this.closeTileW - off;
            for (let i = 0; i < this.closeSpecs.length; i++) {
                const b = this.closeSpecs[i];
                const bx = curX;
                const bw = b.w;
                const bh = b.h * (groundY / 600);
                const by = groundY - bh;
                curX += bw + 50;

                if (bx + bw < 0 || bx > width) continue;

                ctx.fillStyle = b.color;
                ctx.fillRect(bx, by, bw, bh);

                // Linha de topo dos prédios
                ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
                ctx.fillRect(bx, by, bw, 3);

                // Janelas maiores e detalhadas
                ctx.fillStyle = '#ffcc66';
                for (let wy = by + 18; wy < groundY - 20; wy += 26) {
                    for (let wx = bx + 10; wx < bx + bw - 14; wx += 20) {
                        if ((wx * 3 + wy) % 5 !== 0) {
                            ctx.fillRect(wx, wy, 6, 8);
                        }
                    }
                }
            }
        }
    }

    _drawStreet(ctx, width, height, groundY) {
        const streetH = Math.max(80, height - groundY);

        // Asfalto da rua
        ctx.fillStyle = '#161628';
        ctx.fillRect(0, groundY, width, streetH);

        // Calçada
        ctx.fillStyle = '#222238';
        ctx.fillRect(0, groundY, width, Math.min(36, streetH * 0.35));

        // Linha de meio-fio
        ctx.strokeStyle = '#3e3e56';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(0, groundY);
        ctx.lineTo(width, groundY);
        ctx.stroke();

        // Faixas brancas tracejadas na pista
        const dashLen = 45;
        const gapLen  = 35;
        const period  = dashLen + gapLen;
        const dashOff = this.layers[3].offsetX % period;
        const dashY   = groundY + Math.min(18, streetH * 0.2);

        ctx.fillStyle = '#ffffff';
        for (let x = -dashOff; x < width + period; x += period) {
            ctx.fillRect(x, dashY, dashLen, 4);
        }

        // Postes de luz
        const lampPeriod = 260;
        const lampOff    = this.layers[3].offsetX % lampPeriod;
        for (let x = -lampOff; x < width + lampPeriod; x += lampPeriod) {
            ctx.strokeStyle = '#8888aa';
            ctx.lineWidth = 3.5;
            ctx.beginPath();
            ctx.moveTo(x, groundY);
            ctx.lineTo(x, groundY - 70);
            ctx.lineTo(x + 16, groundY - 70);
            ctx.stroke();

            // Lâmpada e brilho amarelo
            ctx.fillStyle = '#ffffcc';
            ctx.beginPath();
            ctx.arc(x + 16, groundY - 73, 6, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = 'rgba(255, 255, 200, 0.08)';
            ctx.beginPath();
            ctx.arc(x + 16, groundY - 73, 26, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    _drawObstacles(ctx, width, height, groundY) {
        // Trilhos de proteção
        ctx.strokeStyle = '#4a4a5a';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(0, groundY - 8);
        ctx.lineTo(width, groundY - 8);
        ctx.stroke();

        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, groundY - 2);
        ctx.lineTo(width, groundY - 2);
        ctx.stroke();

        // Pinos verticais
        const postPeriod = 60;
        const postOff    = this.layers[4].offsetX % postPeriod;
        for (let x = -postOff; x < width + postPeriod; x += postPeriod) {
            ctx.beginPath();
            ctx.moveTo(x, groundY - 12);
            ctx.lineTo(x, groundY + 2);
            ctx.stroke();
        }
    }
}

// ---------------------------------------------------------------------------
// Player — física responsiva com suporte a groundY dinâmico
// ---------------------------------------------------------------------------

class Player {
    static WIDTH    = 40;
    static HEIGHT   = 60;

    // Física base
    static JUMP_FORCE       = -530;   // pulo inicial
    static GRAVITY          = 980;    // gravidade px/s²
    static MAX_FALL_SPEED   = 900;    // limite de queda
    static HORIZONTAL_ACCEL = 650;    // aceleração horizontal
    static MAX_HORIZ_SPEED  = 420;

    constructor(startX = 200, playerIndex = 0, groundY = 600) {
        this.playerIndex = playerIndex;
        this.groundY     = groundY;
        this.x = startX - Player.WIDTH / 2;
        this.y = this.groundY - Player.HEIGHT;
        this.vx = 0;
        this.vy = 0;
        this.state    = PlayerState.RUNNING;
        this.grounded = true;

        // Animação
        this.frameTimer = 0;
        this.legAngle   = 0;
        this.bodyAngle  = 0;

        // Hit flash
        this.hitTimer     = 0;
        this.flashVisible = true;

        // Teia
        this.web = null;

        // Controle de pulo
        this._jumpLockTimer = 0;

        // Vidas e score individual
        this.lives        = 3;
        this.score        = 0;
        this.isEliminated = false;
        this.isVenom      = false;

        // Invulnerabilidade e respawn
        this._invulTimer    = 0;
        this._respawnTimer  = 0;
        this._respawning    = false;
        this._needsRespawn  = false;

        // Força release de teia
        this._forceReleaseWeb = false;
    }

    get hitbox() { return { x: this.x + 6, y: this.y + 6, w: Player.WIDTH - 12, h: Player.HEIGHT - 6 }; }
    get centerX() { return this.x + Player.WIDTH  / 2; }
    get centerY() { return this.y + Player.HEIGHT / 2; }
    get bottom()  { return this.y + Player.HEIGHT; }

    update(dt, ctrl, gameWidth = 1280) {
        const dtS = dt / 1000;
        const events = { firedWeb: false, releasedWeb: false, cancelledWeb: false };

        // Invulnerabilidade após hit
        if (this._invulTimer > 0) this._invulTimer = Math.max(0, this._invulTimer - dt);

        // Contagem regressiva para respawn
        if (this._respawning) {
            this._respawnTimer -= dt;
            if (this._respawnTimer <= 0) {
                this._respawning   = false;
                this._needsRespawn = true;
            }
            return events;
        }

        // Decai lock de pulo
        if (this._jumpLockTimer > 0) this._jumpLockTimer = Math.max(0, this._jumpLockTimer - dt);

        if (this.state === PlayerState.HIT) {
            this._updateHit(dt);
            return events;
        }

        if (this.state === PlayerState.GAME_OVER || this.isEliminated) return events;

        // Movimento horizontal (quando não balançando)
        if (this.state !== PlayerState.SWINGING) {
            if (ctrl.left)  this.vx = Math.max(this.vx - Player.HORIZONTAL_ACCEL * dtS, -Player.MAX_HORIZ_SPEED);
            if (ctrl.right) this.vx = Math.min(this.vx + Player.HORIZONTAL_ACCEL * dtS,  Player.MAX_HORIZ_SPEED);
            if (ctrl.down && !this.grounded) this.vy += 600 * dtS; // queda rápida se segurar baixo no ar

            // Fricção quando nenhuma tecla pressionada
            if (!ctrl.left && !ctrl.right) {
                this.vx *= this.grounded ? 0.72 : 0.98;
                if (Math.abs(this.vx) < 1) this.vx = 0;
            }
        }

        // PULO
        const canJump = this.grounded && this._jumpLockTimer <= 0 &&
                        this.state !== PlayerState.SWINGING &&
                        this.state !== PlayerState.WEB_SHOOTING;

        if (ctrl.jumpJustPressed && canJump) {
            this.vy       = Player.JUMP_FORCE;
            this.grounded = false;
            this.state    = PlayerState.JUMPING;
            this._jumpLockTimer = 120;
        }

        // TEIA
        if (ctrl.webJustPressed && !this.web) {
            events.firedWeb = true;
        }
        if (ctrl.webJustReleased && this.web) {
            if (this.state === PlayerState.SWINGING) events.releasedWeb = true;
            else if (this.state === PlayerState.WEB_SHOOTING) events.cancelledWeb = true;
        }

        // Física conforme estado
        switch (this.state) {
            case PlayerState.RUNNING:
                this._physicsRunning(dtS, gameWidth);
                break;
            case PlayerState.JUMPING:
            case PlayerState.FALLING:
                this._physicsAir(dtS, gameWidth);
                break;
            case PlayerState.WEB_SHOOTING:
                this._physicsWebShooting(dtS, gameWidth);
                break;
            case PlayerState.SWINGING:
                this._physicsSwinging(dtS, gameWidth, ctrl);
                break;
        }

        // Limites estritos da tela (esquerda, direita, topo, chão)
        this.x = Math.max(0, Math.min(gameWidth - Player.WIDTH, this.x));
        this.y = Math.max(0, Math.min(this.groundY - Player.HEIGHT, this.y));
        if (this.x <= 0 && this.vx < 0) this.vx = 0;
        if (this.x >= gameWidth - Player.WIDTH && this.vx > 0) this.vx = 0;
        if (this.y <= 0 && this.vy < 0) this.vy = 0;

        // Animação de pernas
        this.frameTimer += dtS;
        if (this.frameTimer > 1000) this.frameTimer -= 1000;
        if (this.state === PlayerState.RUNNING) {
            this.legAngle = Math.sin(this.frameTimer * Math.PI * 6) * 0.45;
        }

        return events;
    }

    _physicsRunning(dtS, gameWidth) {
        this.x += this.vx * dtS;
        this.x = Math.max(0, Math.min(gameWidth - Player.WIDTH, this.x));
        this.y        = this.groundY - Player.HEIGHT;
        this.vy       = 0;
        this.grounded = true;
        this.bodyAngle = 0;
    }

    _physicsAir(dtS, gameWidth) {
        this.vy += Player.GRAVITY * dtS;
        if (this.vy > Player.MAX_FALL_SPEED) this.vy = Player.MAX_FALL_SPEED;

        this.y += this.vy * dtS;
        this.x += this.vx * dtS;

        this.x = Math.max(0, Math.min(gameWidth - Player.WIDTH, this.x));
        if (this.y < 0) {
            this.y = 0;
            if (this.vy < 0) this.vy = 0;
        }

        if (this.state === PlayerState.JUMPING && this.vy >= 0) {
            this.state = PlayerState.FALLING;
        }

        if (this.bottom >= this.groundY) {
            this._land();
        }
    }

    _physicsWebShooting(dtS, gameWidth) {
        if (!this.grounded) {
            this.vy += Player.GRAVITY * dtS;
            if (this.vy > Player.MAX_FALL_SPEED) this.vy = Player.MAX_FALL_SPEED;
            this.y += this.vy * dtS;
            this.x += this.vx * dtS;
            this.x = Math.max(0, Math.min(gameWidth - Player.WIDTH, this.x));
            if (this.y < 0) {
                this.y = 0;
                if (this.vy < 0) this.vy = 0;
            }
            if (this.bottom >= this.groundY) this._land();
        }
    }

    _physicsSwinging(dtS, gameWidth, ctrl) {
        this.grounded = false;
        if (ctrl) {
            if (ctrl.left)  this.vx = Math.max(this.vx - Player.HORIZONTAL_ACCEL * dtS, -Player.MAX_HORIZ_SPEED);
            if (ctrl.right) this.vx = Math.min(this.vx + Player.HORIZONTAL_ACCEL * dtS,  Player.MAX_HORIZ_SPEED);
        }
        this.x = Math.max(0, Math.min(gameWidth - Player.WIDTH, this.x));
        this.y = Math.max(0, Math.min(this.groundY - Player.HEIGHT, this.y));
        if (this.vx !== 0 || this.vy !== 0) {
            this.bodyAngle = Math.atan2(this.vy, Math.abs(this.vx)) * 0.45;
        }
    }

    _updateHit(dt) {
        this.hitTimer -= dt;
        this.flashVisible = Math.floor(this.hitTimer / 80) % 2 === 0;
        if (this.hitTimer <= 0) {
            if (this.lives > 0) {
                this._respawning   = true;
                this._respawnTimer = 600; // transição fluida para o respawn
                this.flashVisible  = true;
            } else {
                this.state        = PlayerState.GAME_OVER;
                this.isEliminated = true;
            }
        }
    }

    _land() {
        this.y        = this.groundY - Player.HEIGHT;
        this.vy       = 0;
        this.grounded = true;
        this.bodyAngle = 0;
        if (this.state !== PlayerState.HIT && this.state !== PlayerState.GAME_OVER) {
            this.state = PlayerState.RUNNING;
            this._jumpLockTimer = 80;
        }
    }

    startSwinging() {
        this.state         = PlayerState.SWINGING;
        this.grounded      = false;
        this._forceReleaseWeb = false;
    }

    releaseWeb() {
        this.web   = null;
        this.state = PlayerState.FALLING;
        this.grounded = false;
        this._forceReleaseWeb = false;
    }

    cancelWeb() {
        this.web = null;
        this._forceReleaseWeb = false;
        if (this.grounded || this.bottom >= this.groundY) {
            this.state = PlayerState.RUNNING;
        } else {
            this.state = PlayerState.FALLING;
        }
    }

    takeDamage() {
        if (this._invulTimer > 0 || this._respawning) return;
        if (this.state === PlayerState.HIT || this.state === PlayerState.GAME_OVER || this.isEliminated) return;
        this.lives = Math.max(0, this.lives - 1);
        this.web   = null;
        this.isVenom = false; // Retorna à forma normal ao morrer/tomar dano
        this.state = PlayerState.HIT;
        this.hitTimer = 700;
        this._invulTimer = 2500;
        this.grounded = false;
    }

    respawn(startX) {
        this.x          = (startX ?? 200) - Player.WIDTH / 2;
        this.y          = this.groundY - Player.HEIGHT;
        this.vx         = 0;
        this.vy         = 0;
        this.grounded   = true;
        this.bodyAngle  = 0;
        this.web        = null;
        this.isVenom    = false; // Retorna à forma normal no respawn
        this.state      = PlayerState.RUNNING;
        this._respawning    = false;
        this._respawnTimer  = 0;
        this._needsRespawn  = false;
        this._invulTimer    = 2500; // 2.5s de invulnerabilidade ao renascer
        this._jumpLockTimer = 0;
        this.flashVisible   = true;
    }

    draw(ctx, label) {
        if (this.state === PlayerState.HIT && !this.flashVisible) return;
        
        ctx.save();
        // Efeito visual de piscar durante o período de invulnerabilidade
        if (this._invulTimer > 0 && Math.floor(this._invulTimer / 90) % 2 === 0) {
            ctx.globalAlpha = 0.45;
        }

        ctx.translate(this.centerX, this.centerY);
        ctx.rotate(this.bodyAngle);

        const isHit   = this.state === PlayerState.HIT;
        const isRun   = this.state === PlayerState.RUNNING;
        const isSwing = this.state === PlayerState.SWINGING || this.state === PlayerState.WEB_SHOOTING;
        const isFall  = this.state === PlayerState.FALLING || this.state === PlayerState.JUMPING;
        const la      = this.legAngle;

        const isP2 = this.playerIndex === 1;

        let RED_LT, RED_MID, RED_DK, BLU_LT, BLU_MID, BLU_DK, OUTLINE, SHADOW;

        if (this.isVenom) {
            // Traje Venom (skin preta com gradientes e sombras escuras simbióticas)
            RED_LT  = isHit ? '#757575' : '#333338';
            RED_MID = isHit ? '#424242' : '#1c1c20';
            RED_DK  = isHit ? '#212121' : '#0a0a0c';
            BLU_LT  = isHit ? '#9e9e9e' : '#45454e';
            BLU_MID = isHit ? '#616161' : '#222228';
            BLU_DK  = isHit ? '#303030' : '#0f0f12';
            OUTLINE = isHit ? '#b71c1c' : '#000000';
            SHADOW  = 'rgba(0,0,0,0.35)';
        } else {
            RED_LT  = isHit ? '#ff8a80' : (isP2 ? '#ffd54f' : '#ef5350');
            RED_MID = isHit ? '#e53935' : (isP2 ? '#ffb300' : '#c62828');
            RED_DK  = isHit ? '#b71c1c' : (isP2 ? '#ff6f00' : '#8e0000');
            BLU_LT  = isHit ? '#7986cb' : (isP2 ? '#42a5f5' : '#5c6bc0');
            BLU_MID = isHit ? '#3949ab' : (isP2 ? '#1565c0' : '#283593');
            BLU_DK  = isHit ? '#1a237e' : (isP2 ? '#0d47a1' : '#0d1a6e');
            OUTLINE = 'rgba(0,0,0,0.55)';
            SHADOW  = 'rgba(0,0,0,0.18)';
        }

        // Pernas
        const drawLeg = (side, phase) => {
            const hipX=side*7, hipY=13;
            let kneeX, kneeY, footX, footY;
            if (isRun) {
                const swing = Math.sin(phase)*12;
                kneeX=hipX+swing*0.6; kneeY=hipY+15;
                footX=kneeX+swing*0.5; footY=kneeY+13;
            } else if (isSwing) {
                kneeX=hipX+side*5; kneeY=hipY-6;
                footX=hipX+side*3; footY=hipY+6;
            } else if (isFall) {
                kneeX=hipX+side*5; kneeY=hipY+13;
                footX=hipX+side*9; footY=hipY+25;
            } else {
                kneeX=hipX+side*3; kneeY=hipY+14;
                footX=hipX+side*2; footY=hipY+28;
            }
            ctx.save(); ctx.strokeStyle=SHADOW; ctx.lineWidth=10; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(hipX+1,hipY+1); ctx.lineTo(kneeX+1,kneeY+1); ctx.stroke(); ctx.restore();
            const lg1=ctx.createLinearGradient(hipX-4,hipY,hipX+4,kneeY);
            lg1.addColorStop(0,BLU_LT); lg1.addColorStop(0.5,BLU_MID); lg1.addColorStop(1,BLU_DK);
            ctx.strokeStyle=lg1; ctx.lineWidth=8; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(hipX,hipY); ctx.lineTo(kneeX,kneeY); ctx.stroke();
            const lg2=ctx.createLinearGradient(kneeX-3,kneeY,kneeX+3,footY);
            lg2.addColorStop(0,RED_MID); lg2.addColorStop(1,RED_DK);
            ctx.strokeStyle=lg2; ctx.lineWidth=6; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(kneeX,kneeY); ctx.lineTo(footX,footY); ctx.stroke();
            ctx.fillStyle=BLU_DK; ctx.beginPath(); ctx.arc(kneeX,kneeY,3.5,0,Math.PI*2); ctx.fill();
            ctx.fillStyle=BLU_MID; ctx.beginPath(); ctx.ellipse(footX+side*3,footY,6,3.5,side*0.15,0,Math.PI*2); ctx.fill();
            ctx.strokeStyle=BLU_DK; ctx.lineWidth=0.8;
            ctx.beginPath(); ctx.ellipse(footX+side*3,footY,6,3.5,side*0.15,0,Math.PI*2); ctx.stroke();
            ctx.strokeStyle=OUTLINE; ctx.lineWidth=1.2; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(hipX,hipY); ctx.lineTo(kneeX,kneeY); ctx.lineTo(footX,footY); ctx.stroke();
        };
        drawLeg(-1, la+Math.PI); drawLeg(1, la);

        // Braços
        const drawArm = (side) => {
            const sX=side*11, sY=-9;
            let eX, eY, hX, hY;
            if (isSwing) {
                if (side===1){eX=sX+9;eY=sY-11;hX=sX+18;hY=sY-22;}
                else{eX=sX-4;eY=sY+8;hX=sX-8;hY=sY+16;}
            } else if (isRun) {
                const swing=Math.sin(la*(side===1?-1:1))*11;
                eX=sX+swing*0.4; eY=sY+10; hX=sX+swing*0.7; hY=sY+21;
            } else if (isFall) {
                eX=sX+side*5; eY=sY+7; hX=sX+side*11; hY=sY+17;
            } else {
                eX=sX+side*4; eY=sY+9; hX=sX+side*8; hY=sY+19;
            }
            ctx.save(); ctx.strokeStyle=SHADOW; ctx.lineWidth=9; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(sX+1,sY+1); ctx.lineTo(eX+1,eY+1); ctx.stroke(); ctx.restore();
            const ag1=ctx.createLinearGradient(sX-3,sY,sX+3,eY);
            ag1.addColorStop(0,RED_LT); ag1.addColorStop(0.6,RED_MID); ag1.addColorStop(1,RED_DK);
            ctx.strokeStyle=ag1; ctx.lineWidth=7; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(sX,sY); ctx.lineTo(eX,eY); ctx.stroke();
            const ag2=ctx.createLinearGradient(eX-2,eY,eX+2,hY);
            ag2.addColorStop(0,BLU_LT); ag2.addColorStop(1,BLU_DK);
            ctx.strokeStyle=ag2; ctx.lineWidth=5; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(eX,eY); ctx.lineTo(hX,hY); ctx.stroke();
            ctx.fillStyle=RED_DK; ctx.beginPath(); ctx.arc(eX,eY,3,0,Math.PI*2); ctx.fill();
            ctx.fillStyle=RED_MID; ctx.beginPath(); ctx.arc(hX,hY,4,0,Math.PI*2); ctx.fill();
            if (isSwing && side===1) {
                ctx.strokeStyle='#ffe082'; ctx.lineWidth=1.2;
                ctx.beginPath(); ctx.arc(hX,hY,5.5,0,Math.PI*2); ctx.stroke();
            }
            ctx.strokeStyle=OUTLINE; ctx.lineWidth=1; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(sX,sY); ctx.lineTo(eX,eY); ctx.lineTo(hX,hY); ctx.stroke();
        };
        drawArm(-1); drawArm(1);

        // Tronco
        ctx.fillStyle=SHADOW; ctx.beginPath(); ctx.ellipse(2,-3,14,19,0,0,Math.PI*2); ctx.fill();
        const tg=ctx.createLinearGradient(-14,-25,14,18);
        tg.addColorStop(0,RED_LT); tg.addColorStop(0.4,RED_MID); tg.addColorStop(1,RED_DK);
        ctx.fillStyle=tg; ctx.beginPath();
        ctx.moveTo(0,-25); ctx.bezierCurveTo(5,-26,14,-18,14,-15); ctx.bezierCurveTo(15,-5,14,8,12,15);
        ctx.lineTo(0,19); ctx.lineTo(-12,15); ctx.bezierCurveTo(-14,8,-15,-5,-14,-15);
        ctx.bezierCurveTo(-14,-18,-5,-26,0,-25); ctx.closePath(); ctx.fill();
        const bg=ctx.createLinearGradient(-13,4,13,19);
        bg.addColorStop(0,BLU_LT); bg.addColorStop(1,BLU_DK);
        ctx.fillStyle=bg;
        for (const side of [-1,1]) {
            ctx.beginPath(); ctx.moveTo(side*6,5); ctx.lineTo(side*13,5);
            ctx.lineTo(side*12,15); ctx.lineTo(0,19); ctx.closePath(); ctx.fill();
        }

        // Cabeça
        const HY=-36;
        const ng=ctx.createLinearGradient(-4,-28,4,-24);
        ng.addColorStop(0,RED_MID); ng.addColorStop(1,RED_DK);
        ctx.fillStyle=ng; ctx.beginPath(); ctx.ellipse(0,-26,4,3,0,0,Math.PI*2); ctx.fill();
        const hg=ctx.createRadialGradient(-4,HY-4,2,0,HY,14);
        hg.addColorStop(0,RED_LT); hg.addColorStop(0.5,RED_MID); hg.addColorStop(1,RED_DK);
        ctx.fillStyle=hg; ctx.beginPath(); ctx.ellipse(0,HY,12,13.5,0,0,Math.PI*2); ctx.fill();

        // Olhos
        const eyeColor   = isHit ? '#ffcdd2' : '#ffffff';
        const eyeOutline = isHit ? '#b71c1c' : (this.isVenom ? '#ffffff' : '#000000');
        const eyeGloss   = isHit ? 'rgba(255,200,200,0.7)' : 'rgba(255,255,255,0.85)';
        const drawEye=(side)=>{
            ctx.fillStyle=eyeColor; ctx.beginPath();
            ctx.moveTo(side*2,HY-2); ctx.bezierCurveTo(side*4,HY-8,side*10,HY-10,side*12,HY-6);
            ctx.bezierCurveTo(side*13,HY-3,side*11,HY+1,side*8,HY+2);
            ctx.bezierCurveTo(side*5,HY+3,side*1,HY+1,side*2,HY-2); ctx.closePath(); ctx.fill();
            ctx.strokeStyle=eyeOutline; ctx.lineWidth=1.1; ctx.beginPath();
            ctx.moveTo(side*2,HY-2); ctx.bezierCurveTo(side*4,HY-8,side*10,HY-10,side*12,HY-6);
            ctx.bezierCurveTo(side*13,HY-3,side*11,HY+1,side*8,HY+2);
            ctx.bezierCurveTo(side*5,HY+3,side*1,HY+1,side*2,HY-2); ctx.closePath(); ctx.stroke();
            ctx.fillStyle=eyeGloss; ctx.beginPath(); ctx.ellipse(side*5.5,HY-6.5,2.5,1.8,side*-0.5,0,Math.PI*2); ctx.fill();
        };
        drawEye(-1); drawEye(1);

        ctx.strokeStyle=OUTLINE; ctx.lineWidth=1.4;
        ctx.beginPath(); ctx.ellipse(0,HY,12,13.5,0,0,Math.PI*2); ctx.stroke();
        ctx.strokeStyle=OUTLINE; ctx.lineWidth=1.3;
        ctx.beginPath(); ctx.moveTo(0,-25); ctx.bezierCurveTo(5,-26,14,-18,14,-15);
        ctx.bezierCurveTo(15,-5,14,8,12,15); ctx.lineTo(0,19); ctx.lineTo(-12,15);
        ctx.bezierCurveTo(-14,8,-15,-5,-14,-15); ctx.bezierCurveTo(-14,-18,-5,-26,0,-25); ctx.closePath(); ctx.stroke();

        ctx.restore();

        // Label P1/P2 acima do personagem
        if (label) {
            ctx.save();
            ctx.font         = 'bold 13px sans-serif';
            ctx.textAlign    = 'center';
            ctx.textBaseline = 'bottom';
            if (this.isVenom) {
                ctx.fillStyle = '#e1bee7';
                ctx.fillText(`${label} (VENOM 2x)`, this.centerX, this.y - 4);
            } else {
                ctx.fillStyle = this.playerIndex === 0 ? '#ef5350' : '#ffd54f';
                ctx.fillText(label, this.centerX, this.y - 4);
            }
            ctx.restore();
        }
    }
}

// ---------------------------------------------------------------------------
// Web — Balanço em formato de "A" (arco de filme do Homem-Aranha)
// ---------------------------------------------------------------------------

class Web {
    constructor(player, anchorX, anchorY) {
        this.anchorX = anchorX;
        this.anchorY = anchorY;
        this.tipX    = player.centerX;
        this.tipY    = player.centerY;

        const dx = anchorX - player.centerX;
        const dy = anchorY - player.centerY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        this._dirX = dist > 0 ? dx / dist : 0;
        this._dirY = dist > 0 ? dy / dist : -1;
        this._travelDist  = 0;
        this._totalDist   = dist;
        this.isTaut       = false;
        this._travelTimer = 0;

        // Trajetória do arco em "A"
        this.swingProgress = 0;    // 0.0 a 1.0
        this.swingDuration = 780;  // ms para completar o arco completo
        this.startX = player.x;
        this.startY = player.y;
        this.arcSpan = 380;        // distância horizontal percorrida no balanço
        this.arcLift = 140;        // elevação até o pico (topo do arco "A")
    }

    scrollAnchor(dx) {
        this.anchorX -= dx;
        this.startX   -= dx;
        if (!this.isTaut) this.tipX -= dx;
    }

    update(dt, player, ctrl = null, gameWidth = 1280) {
        const dtS = dt / 1000;
        if (!this.isTaut) {
            this._travelTimer += dt;
            if (this._travelTimer > 400) return;
            // Teia viaja em altíssima velocidade para prender rápido e com fluidez
            const speed = 2500 * dtS;
            this._travelDist += speed;
            if (this._travelDist >= this._totalDist) {
                this.isTaut = true;
                this.tipX = this.anchorX;
                this.tipY = this.anchorY;
                this.startX = player.x;
                this.startY = player.y;

                // Configura parâmetros do balanço em A adaptados à velocidade atual
                const forwardMomentum = Math.max(player.vx, 320);
                this.arcSpan = Math.max(320, forwardMomentum * 0.9);
                // Elevação em A: sobe em direção ao pico
                const availableHeight = Math.max(70, player.groundY - 110 - this.anchorY);
                this.arcLift = Math.min(160, Math.max(90, availableHeight * 0.75));
                this.swingProgress = 0;
            } else {
                this.tipX = player.centerX + this._dirX * this._travelDist;
                this.tipY = player.centerY + this._dirY * this._travelDist;
            }
        } else {
            // === BALANÇO EM ARCO FORMATO "A" (HOMEM-ARANHA) ===
            this.swingProgress += dt / this.swingDuration;
            const p = Math.min(1.0, this.swingProgress);

            // Controle de movimento para frente e para trás durante o balanço na teia
            if (ctrl && ctrl.left) {
                this.startX = Math.max(0, this.startX - 360 * dtS);
            } else if (ctrl && ctrl.right) {
                this.startX = Math.min(gameWidth - Player.WIDTH, this.startX + 220 * dtS);
            }

            // Avanço horizontal suave com impulso
            const easeX = Math.sin(p * Math.PI * 0.5);
            const targetX = this.startX + this.arcSpan * easeX;

            // Formato de "A": sobe em diagonal até o pico no meio (p = 0.5) e desce do outro lado
            // Parábola invertida: 4 * p * (1 - p) tem valor 1.0 exatamente em p = 0.5
            const peakFactor = 4 * p * (1 - p);
            const descentOffset = p * 25;
            const targetY = this.startY - (this.arcLift * peakFactor) + descentOffset;

            const prevX = player.x;
            const prevY = player.y;

            // Trava o personagem rigidamente nos limites visíveis da tela (esquerda, direita, topo, chão)
            player.x = Math.max(0, Math.min(gameWidth - Player.WIDTH, targetX));
            player.y = Math.max(0, Math.min(player.groundY - Player.HEIGHT, targetY));

            if (dtS > 0) {
                player.vx = (player.x - prevX) / dtS;
                player.vy = (player.y - prevY) / dtS;
            }

            // Fim natural do arco: solta a teia com impulso de inércia para frente
            if (this.swingProgress >= 1.0) {
                player.vx = Math.max(player.vx, 380);
                player.vy = Math.min(player.vy, -80);
                player._forceReleaseWeb = true;
            }
        }
    }

    draw(ctx, player) {
        ctx.save();
        ctx.strokeStyle = '#f2f2ff';
        ctx.lineWidth = 2.5;
        ctx.beginPath();

        // Teia sai da mão do personagem
        const handX = player.centerX + (player.bodyAngle > 0 ? 12 : 8);
        const handY = player.centerY - 10;
        ctx.moveTo(handX, handY);

        if (this.isTaut) {
            // Teia esticada e visível com leve tensão natural
            const mx = (handX + this.anchorX) / 2;
            const my = (handY + this.anchorY) / 2 - 2;
            ctx.quadraticCurveTo(mx, my, this.anchorX, this.anchorY);
        } else {
            ctx.lineTo(this.tipX, this.tipY);
        }
        ctx.stroke();

        // Ponto de ancoragem no prédio
        if (this.isTaut) {
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(this.anchorX, this.anchorY, 4, 0, Math.PI * 2);
            ctx.fill();

            ctx.strokeStyle = 'rgba(130, 180, 255, 0.8)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(this.anchorX, this.anchorY, 7, 0, Math.PI * 2);
            ctx.stroke();
        }
        ctx.restore();
    }
}

// ---------------------------------------------------------------------------
// Zombie — Duende Verde (preservado visual e comportamento original)
// ---------------------------------------------------------------------------

class Zombie {
    static TYPES = {
        common: { speedFactor: 1.0,  w: 36, h: 60, color: '#4a8a4a', headColor: '#3a7a3a' },
        fast:   { speedFactor: 1.75, w: 28, h: 50, color: '#8a8a20', headColor: '#7a7a10' },
        large:  { speedFactor: 0.6,  w: 52, h: 90, color: '#8a3a3a', headColor: '#7a2a2a' },
    };

    constructor() {
        this.isOffscreen = true;
        this.type  = 'common';
        this.x = 0; this.y = 0; this.w = 36; this.h = 60;
        this.color = '#4a8a4a'; this.headColor = '#3a7a3a';
        this.speed = 0; this._animTimer = 0; this._legAngle = 0;
    }

    reset(type, x, scrollSpeed, groundY = 600) {
        const cfg = Zombie.TYPES[type] || Zombie.TYPES.common;
        this.type = type; this.w = cfg.w; this.h = cfg.h;
        this.color = cfg.color; this.headColor = cfg.headColor;
        this.speed = scrollSpeed * cfg.speedFactor * 60;
        this.x = x;
        this.y = groundY - this.h;
        this.isOffscreen = false;
        this._animTimer = 0;
        this._legAngle = 0;
    }

    get hitbox() {
        if (this.type === 'large') {
            return { x: this.x + 10, y: this.y + 12, w: this.w - 20, h: this.h - 20 };
        }
        return { x: this.x + 4, y: this.y + 4, w: this.w - 8, h: this.h - 4 };
    }

    update(dt, scrollSpeed) {
        const dtS = dt / 1000;
        this.x -= this.speed * dtS;
        this._animTimer += dtS;
        this._legAngle = Math.sin(this._animTimer * Math.PI * 4) * 0.3;
        if (this.x + this.w < -30) this.isOffscreen = true;
    }

    draw(ctx) {
        if (this.isOffscreen) return;
        ctx.save();
        const cx=this.x+this.w/2, top=this.y, s=this.h/60, la=this._legAngle;
        const G_LT='#81c784', G_MID='#388e3c', G_DK='#1b5e20';
        const P_LT='#9c27b0', P_DK='#4a148c';
        const MTL='#b0bec5', MTL_D='#546e7a';
        const SKIN='#a5d6a7', ORG='#e65100', YEL='#ffd600';
        const OUTLINE='rgba(0,0,0,0.5)', SHAD='rgba(0,0,0,0.15)';

        if (this.type==='large') {
            const bx=cx, by=top+this.h+3*s;
            ctx.fillStyle='rgba(0,0,0,0.2)'; ctx.beginPath(); ctx.ellipse(bx,by+10*s,30*s,5*s,0,0,Math.PI*2); ctx.fill();
            const bbg=ctx.createLinearGradient(bx-30*s,by-8*s,bx+30*s,by+8*s);
            bbg.addColorStop(0,MTL_D); bbg.addColorStop(0.3,MTL); bbg.addColorStop(0.7,MTL_D); bbg.addColorStop(1,'#263238');
            ctx.fillStyle=bbg; ctx.beginPath();
            ctx.moveTo(bx-30*s,by+2*s); ctx.bezierCurveTo(bx-22*s,by-8*s,bx-5*s,by-6*s,bx,by-5*s);
            ctx.bezierCurveTo(bx+5*s,by-6*s,bx+22*s,by-8*s,bx+30*s,by+2*s);
            ctx.bezierCurveTo(bx+22*s,by+8*s,bx+5*s,by+7*s,bx,by+6*s);
            ctx.bezierCurveTo(bx-5*s,by+7*s,bx-22*s,by+8*s,bx-30*s,by+2*s); ctx.fill();
            ctx.strokeStyle=OUTLINE; ctx.lineWidth=1*s; ctx.stroke();
            ctx.fillStyle='rgba(77,208,225,0.65)'; ctx.beginPath(); ctx.ellipse(bx,by+9*s,18*s,3*s,0,0,Math.PI*2); ctx.fill();
            ctx.fillStyle='rgba(77,208,225,0.25)'; ctx.beginPath(); ctx.ellipse(bx,by+12*s,22*s,5*s,0,0,Math.PI*2); ctx.fill();
            ctx.strokeStyle='rgba(77,208,225,0.7)'; ctx.lineWidth=1.2*s;
            for (let i=-2;i<=2;i++){ctx.beginPath();ctx.moveTo(bx+i*8*s,by-5*s);ctx.lineTo(bx+i*8*s,by+6*s);ctx.stroke();}
            ctx.fillStyle=MTL;
            for (const rx of [-22,-10,0,10,22]){ctx.beginPath();ctx.arc(bx+rx*s,by,1.5*s,0,Math.PI*2);ctx.fill();}
        }

        for (const side of [-1,1]) {
            const phase=la*side, hipX=cx+side*6*s, hipY=top+this.h*0.72;
            const kneeX=hipX+Math.sin(phase)*9*s, kneeY=hipY+11*s;
            const footX=kneeX+side*5*s, footY=kneeY+9*s;
            ctx.save(); ctx.strokeStyle=SHAD; ctx.lineWidth=10*s; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(hipX+1*s,hipY+1*s); ctx.lineTo(kneeX+1*s,kneeY+1*s); ctx.stroke(); ctx.restore();
            const ulg=ctx.createLinearGradient(hipX-5*s,hipY,hipX+5*s,kneeY);
            ulg.addColorStop(0,G_LT); ulg.addColorStop(0.5,G_MID); ulg.addColorStop(1,G_DK);
            ctx.strokeStyle=ulg; ctx.lineWidth=8*s; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(hipX,hipY); ctx.lineTo(kneeX,kneeY); ctx.stroke();
            const llg=ctx.createLinearGradient(kneeX-3*s,kneeY,kneeX+3*s,footY);
            llg.addColorStop(0,MTL_D); llg.addColorStop(1,'#263238');
            ctx.strokeStyle=llg; ctx.lineWidth=6*s; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(kneeX,kneeY); ctx.lineTo(footX,footY); ctx.stroke();
            const kpg=ctx.createRadialGradient(kneeX-2*s,kneeY-2*s,s,kneeX,kneeY,5*s);
            kpg.addColorStop(0,P_LT); kpg.addColorStop(1,P_DK);
            ctx.fillStyle=kpg; ctx.beginPath(); ctx.arc(kneeX,kneeY,4.5*s,0,Math.PI*2); ctx.fill();
            ctx.strokeStyle=OUTLINE; ctx.lineWidth=0.8*s; ctx.stroke();
            ctx.fillStyle='#37474f'; ctx.beginPath(); ctx.ellipse(footX+side*3*s,footY,6*s,3*s,side*0.2,0,Math.PI*2); ctx.fill();
            ctx.strokeStyle=OUTLINE; ctx.lineWidth=0.8*s; ctx.beginPath(); ctx.ellipse(footX+side*3*s,footY,6*s,3*s,side*0.2,0,Math.PI*2); ctx.stroke();
            ctx.strokeStyle=OUTLINE; ctx.lineWidth=1.2*s; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(hipX,hipY); ctx.lineTo(kneeX,kneeY); ctx.lineTo(footX,footY); ctx.stroke();
        }

        ctx.fillStyle=SHAD; ctx.beginPath(); ctx.ellipse(cx+2*s,top+this.h*0.42,14*s,18*s,0,0,Math.PI*2); ctx.fill();
        const tg=ctx.createLinearGradient(cx-13*s,top+this.h*0.22,cx+13*s,top+this.h*0.58);
        tg.addColorStop(0,G_LT);tg.addColorStop(0.35,G_MID);tg.addColorStop(0.7,G_DK);tg.addColorStop(1,'#0a3d0a');
        ctx.fillStyle=tg; ctx.beginPath();
        ctx.moveTo(cx,top+this.h*0.22);
        ctx.bezierCurveTo(cx+6*s,top+this.h*0.22,cx+13*s,top+this.h*0.28,cx+12*s,top+this.h*0.34);
        ctx.lineTo(cx+11*s,top+this.h*0.57); ctx.lineTo(cx,top+this.h*0.60); ctx.lineTo(cx-11*s,top+this.h*0.57);
        ctx.lineTo(cx-12*s,top+this.h*0.34);
        ctx.bezierCurveTo(cx-13*s,top+this.h*0.28,cx-6*s,top+this.h*0.22,cx,top+this.h*0.22); ctx.closePath(); ctx.fill();
        const cpg=ctx.createLinearGradient(cx-7*s,top+this.h*0.27,cx+7*s,top+this.h*0.50);
        cpg.addColorStop(0,P_LT);cpg.addColorStop(0.6,P_DK);cpg.addColorStop(1,'#1a0033');
        ctx.fillStyle=cpg; ctx.beginPath();
        ctx.moveTo(cx,top+this.h*0.26); ctx.lineTo(cx+7*s,top+this.h*0.31); ctx.lineTo(cx+6*s,top+this.h*0.48);
        ctx.lineTo(cx,top+this.h*0.51); ctx.lineTo(cx-6*s,top+this.h*0.48); ctx.lineTo(cx-7*s,top+this.h*0.31); ctx.closePath(); ctx.fill();

        const belt_g=ctx.createLinearGradient(cx-11*s,top+this.h*0.55,cx+11*s,top+this.h*0.60);
        belt_g.addColorStop(0,'#bf360c');belt_g.addColorStop(0.5,'#f57f17');belt_g.addColorStop(1,'#bf360c');
        ctx.fillStyle=belt_g; ctx.fillRect(cx-11*s,top+this.h*0.55,22*s,5*s);
        ctx.fillStyle='rgba(255,200,0,0.6)'; ctx.beginPath(); ctx.arc(cx,top+this.h*0.575,3*s,0,Math.PI*2); ctx.fill();
        ctx.strokeStyle=OUTLINE; ctx.lineWidth=1.2*s;
        ctx.beginPath(); ctx.moveTo(cx,top+this.h*0.22);
        ctx.bezierCurveTo(cx+13*s,top+this.h*0.26,cx+12*s,top+this.h*0.34,cx+11*s,top+this.h*0.57);
        ctx.lineTo(cx,top+this.h*0.60); ctx.lineTo(cx-11*s,top+this.h*0.57);
        ctx.bezierCurveTo(cx-12*s,top+this.h*0.34,cx-13*s,top+this.h*0.26,cx,top+this.h*0.22); ctx.closePath(); ctx.stroke();

        for (const side of [-1,1]) {
            const phase=la*-side;
            const sX=cx+side*12*s, sY=top+this.h*0.29;
            const eX=sX+side*7*s+Math.sin(phase)*5*s, eY=sY+10*s;
            const hX=eX+side*6*s, hY=eY+8*s;
            ctx.save(); ctx.strokeStyle=SHAD; ctx.lineWidth=9*s; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(sX+s,sY+s); ctx.lineTo(eX+s,eY+s); ctx.stroke(); ctx.restore();
            const aug=ctx.createLinearGradient(sX-4*s,sY,sX+4*s,eY);
            aug.addColorStop(0,G_LT);aug.addColorStop(0.6,G_MID);aug.addColorStop(1,G_DK);
            ctx.strokeStyle=aug; ctx.lineWidth=7*s; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(sX,sY); ctx.lineTo(eX,eY); ctx.stroke();
            ctx.strokeStyle=G_DK; ctx.lineWidth=5*s;
            ctx.beginPath(); ctx.moveTo(eX,eY); ctx.lineTo(hX,hY); ctx.stroke();
            ctx.fillStyle=ORG; ctx.beginPath(); ctx.arc(hX,hY,4.5*s,0,Math.PI*2); ctx.fill();
            ctx.strokeStyle='#bf360c'; ctx.lineWidth=0.8*s; ctx.stroke();
            ctx.strokeStyle=OUTLINE; ctx.lineWidth=1.1*s; ctx.lineCap='round';
            ctx.beginPath(); ctx.moveTo(sX,sY); ctx.lineTo(eX,eY); ctx.lineTo(hX,hY); ctx.stroke();
        }

        const hcx=cx, hcy=top+this.h*0.13, hr=this.w*0.42;
        ctx.fillStyle=SHAD; ctx.beginPath(); ctx.ellipse(hcx+2*s,hcy+2*s,hr+2*s,hr*1.1,0,0,Math.PI*2); ctx.fill();
        const hg2=ctx.createRadialGradient(hcx-4*s,hcy-5*s,2*s,hcx,hcy,hr*1.1);
        hg2.addColorStop(0,SKIN);hg2.addColorStop(0.6,G_MID);hg2.addColorStop(1,G_DK);
        ctx.fillStyle=hg2; ctx.beginPath(); ctx.ellipse(hcx,hcy,hr,hr*1.08,0,0,Math.PI*2); ctx.fill();
        const hmg=ctx.createLinearGradient(hcx-hr,hcy-hr,hcx+hr,hcy+hr*0.5);
        hmg.addColorStop(0,P_LT);hmg.addColorStop(0.5,P_DK);hmg.addColorStop(1,'#0d001a');
        ctx.fillStyle=hmg; ctx.beginPath();
        ctx.moveTo(hcx-hr*0.9,hcy+hr*0.05);
        ctx.bezierCurveTo(hcx-hr*0.85,hcy-hr*1.35,hcx+hr*0.85,hcy-hr*1.35,hcx+hr*0.9,hcy+hr*0.05);
        ctx.bezierCurveTo(hcx+hr*0.6,hcy+hr*0.55,hcx,hcy+hr*0.65,hcx,hcy+hr*0.65);
        ctx.bezierCurveTo(hcx,hcy+hr*0.65,hcx-hr*0.6,hcy+hr*0.55,hcx-hr*0.9,hcy+hr*0.05); ctx.fill();

        for (const side of [-1,1]) {
            const eyeG=ctx.createLinearGradient(hcx+side*hr*0.2,hcy-hr*0.15,hcx+side*hr*0.7,hcy+hr*0.3);
            eyeG.addColorStop(0,'#fff176');eyeG.addColorStop(0.5,YEL);eyeG.addColorStop(1,'#f57f17');
            ctx.fillStyle=eyeG; ctx.beginPath();
            ctx.moveTo(hcx+side*hr*0.15,hcy-hr*0.12); ctx.lineTo(hcx+side*hr*0.72,hcy-hr*0.18);
            ctx.lineTo(hcx+side*hr*0.75,hcy+hr*0.28); ctx.lineTo(hcx+side*hr*0.12,hcy+hr*0.28); ctx.closePath(); ctx.fill();
            ctx.strokeStyle='#e65100'; ctx.lineWidth=1*s;
            ctx.beginPath(); ctx.moveTo(hcx+side*hr*0.15,hcy-hr*0.12); ctx.lineTo(hcx+side*hr*0.72,hcy-hr*0.18);
            ctx.lineTo(hcx+side*hr*0.75,hcy+hr*0.28); ctx.lineTo(hcx+side*hr*0.12,hcy+hr*0.28); ctx.closePath(); ctx.stroke();
        }

        ctx.fillStyle='#1a0a00'; ctx.beginPath();
        ctx.moveTo(hcx-hr*0.35,hcy+hr*0.46);
        ctx.bezierCurveTo(hcx-hr*0.3,hcy+hr*0.65,hcx+hr*0.3,hcy+hr*0.65,hcx+hr*0.35,hcy+hr*0.46);
        ctx.closePath(); ctx.fill();

        ctx.strokeStyle=OUTLINE; ctx.lineWidth=1.3*s;
        ctx.beginPath(); ctx.ellipse(hcx,hcy,hr,hr*1.08,0,0,Math.PI*2); ctx.stroke();

        if (this.type==='fast') {
            ctx.strokeStyle='rgba(120,255,130,0.35)'; ctx.lineWidth=1.5*s;
            for (let i=0; i<4; i++) {
                ctx.beginPath(); ctx.moveTo(this.x-8*s-i*7*s,top+this.h*(0.25+i*0.13));
                ctx.lineTo(this.x-24*s-i*9*s,top+this.h*(0.25+i*0.13)); ctx.stroke();
            }
        }
        ctx.restore();
    }
}

// ---------------------------------------------------------------------------
// Coin — Moeda colecionável com animação de brilho e rotação 3D
// ---------------------------------------------------------------------------

class Coin {
    static RADIUS = 14;

    constructor() {
        this.x = 0;
        this.y = 0;
        this.relY = 24;
        this.isOffscreen = true;
        this.collectedByP1 = false;
        this.collectedByP2 = false;
        this.animTimer = Math.random() * 10;
        this.value = 1;
        this.scoreBonus = 25;
    }

    reset(x, relY = 24) {
        this.x = x;
        this.relY = relY;
        this.y = 0;
        this.isOffscreen = false;
        this.collectedByP1 = false;
        this.collectedByP2 = false;
        this.animTimer = Math.random() * 10;
    }

    getHitbox(groundY) {
        const cy = groundY - this.relY;
        return {
            x: this.x - Coin.RADIUS,
            y: cy - Coin.RADIUS,
            w: Coin.RADIUS * 2,
            h: Coin.RADIUS * 2
        };
    }

    update(dt, scrollSpeed) {
        if (this.isOffscreen) return;
        const dtS = dt / 1000;
        this.x -= scrollSpeed * 60 * dtS;
        this.animTimer += dtS * 6;
        if (this.x < -40) this.isOffscreen = true;
    }

    draw(ctx, groundY) {
        if (this.isOffscreen) return;
        ctx.save();

        const scaleX = Math.cos(this.animTimer);
        const r = Coin.RADIUS;
        const cx = this.x;
        const cy = (groundY - this.relY) + Math.sin(this.animTimer * 0.5) * 3; // flutuação suave

        // Brilho exterior dourado
        ctx.fillStyle = 'rgba(255, 215, 0, 0.28)';
        ctx.beginPath();
        ctx.arc(cx, cy, r + 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.translate(cx, cy);
        ctx.scale(Math.abs(scaleX) < 0.12 ? 0.12 : scaleX, 1);

        // Borda e corpo da moeda
        const coinGrad = ctx.createLinearGradient(-r, -r, r, r);
        coinGrad.addColorStop(0, '#fff9c4');
        coinGrad.addColorStop(0.3, '#ffd700');
        coinGrad.addColorStop(0.8, '#ff9800');
        coinGrad.addColorStop(1, '#e65100');

        ctx.fillStyle = coinGrad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#fffde7';
        ctx.lineWidth = 1.6;
        ctx.stroke();

        // Anel interno da moeda
        ctx.strokeStyle = 'rgba(230, 81, 0, 0.65)';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.65, 0, Math.PI * 2);
        ctx.stroke();

        // Símbolo de teia / aranha
        ctx.fillStyle = '#fffde7';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🕷', 0, 0);

        ctx.restore();
    }
}

// ---------------------------------------------------------------------------
// Potion — Poção de Transformação (Homem-Aranha <-> Venom)
// ---------------------------------------------------------------------------

class Potion {
    static RADIUS = 18;

    constructor() {
        this.x = 0;
        this.relY = 50;
        this.isOffscreen = true;
        this.targetPlayer = 'solo'; // 'solo' | 'p1' | 'p2'
        this.milestone = 0;
        this.animTimer = 0;
    }

    reset(x, relY, targetPlayer, milestone) {
        this.x = x;
        this.relY = relY;
        this.targetPlayer = targetPlayer;
        this.milestone = milestone;
        this.isOffscreen = false;
        this.animTimer = 0;
    }

    getHitbox(groundY) {
        const cy = groundY - this.relY;
        return {
            x: this.x - Potion.RADIUS,
            y: cy - Potion.RADIUS,
            w: Potion.RADIUS * 2,
            h: Potion.RADIUS * 2
        };
    }

    update(dt, scrollSpeed) {
        if (this.isOffscreen) return;
        const dtS = dt / 1000;
        this.x -= scrollSpeed * 60 * dtS;
        this.animTimer += dtS * 4;
        if (this.x < -60) this.isOffscreen = true;
    }

    draw(ctx, groundY) {
        if (this.isOffscreen) return;
        ctx.save();

        const cx = this.x;
        const cy = (groundY - this.relY) + Math.sin(this.animTimer) * 4;
        const r = Potion.RADIUS;

        // Aura pulsante de energia simbiótica (púrpura / neon)
        const pulse = 0.5 + 0.5 * Math.sin(this.animTimer * 2.5);
        const auraGrad = ctx.createRadialGradient(cx, cy, r * 0.3, cx, cy, r * 1.9);
        auraGrad.addColorStop(0, 'rgba(171, 71, 188, 0.50)');
        auraGrad.addColorStop(0.6, 'rgba(106, 27, 154, 0.25)');
        auraGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = auraGrad;
        ctx.beginPath();
        ctx.arc(cx, cy, r * 1.9 + pulse * 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.translate(cx, cy);

        // Corpo do frasco
        const flaskGrad = ctx.createLinearGradient(-r, -r, r, r);
        flaskGrad.addColorStop(0, '#ba68c8');
        flaskGrad.addColorStop(0.35, '#7b1fa2');
        flaskGrad.addColorStop(0.75, '#311b92');
        flaskGrad.addColorStop(1, '#0a0026');

        ctx.fillStyle = flaskGrad;
        ctx.beginPath();
        ctx.arc(0, 3, r * 0.85, 0, Math.PI * 2);
        ctx.fill();

        // Bocal do frasco
        ctx.fillStyle = '#4a148c';
        ctx.fillRect(-r * 0.38, -r * 0.95, r * 0.76, r * 0.4);

        // Rolha
        ctx.fillStyle = '#8d6e63';
        ctx.fillRect(-r * 0.3, -r * 1.18, r * 0.6, r * 0.28);

        // Contorno de vidro brilhante
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.arc(0, 3, r * 0.85, 0, Math.PI * 2);
        ctx.stroke();

        // Reflexo de luz no vidro
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(-2, 1, r * 0.6, -Math.PI * 0.75, -Math.PI * 0.25);
        ctx.stroke();

        // Símbolo / Texto da Poção
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🧪', 0, 4);

        ctx.restore();
    }
}

// ---------------------------------------------------------------------------
// Particle & Collision
// ---------------------------------------------------------------------------

class Particle {
    constructor() { this.isDead = true; this.half = 'all'; }
    init(x, y, vx, vy, lifetime, color, kind, half = 'all') {
        this.x = x; this.y = y; this.vx = vx; this.vy = vy;
        this.lifetime = lifetime; this.age = 0; this.color = color; this.kind = kind;
        this.half = half; this.isDead = false;
    }
    update(dt) {
        if (this.isDead) return;
        this.age += dt;
        if (this.age >= this.lifetime) { this.isDead = true; return; }
        this.x += this.vx * (dt / 1000); this.y += this.vy * (dt / 1000);
        if (this.kind === 'dust') this.vy += 800 * (dt / 1000);
    }
    draw(ctx) {
        if (this.isDead) return;
        const alpha = 1 - (this.age / this.lifetime);
        ctx.save(); ctx.globalAlpha = alpha;
        switch(this.kind) {
            case 'silk':
                ctx.strokeStyle = this.color; ctx.lineWidth = 1.5;
                ctx.beginPath(); ctx.moveTo(this.x, this.y); ctx.lineTo(this.x + this.vx * 0.05, this.y + this.vy * 0.05); ctx.stroke();
                break;
            case 'dust': {
                ctx.fillStyle = this.color;
                const r = 3 * (1 - this.age / this.lifetime) + 1;
                ctx.beginPath(); ctx.arc(this.x, this.y, r, 0, Math.PI * 2); ctx.fill();
                break;
            }
            case 'coinSparkle': {
                ctx.fillStyle = this.color;
                const r = 2.8 * (1 - this.age / this.lifetime) + 1;
                ctx.beginPath(); ctx.arc(this.x, this.y, r, 0, Math.PI * 2); ctx.fill();
                break;
            }
            case 'symbioteSparkle': {
                ctx.fillStyle = this.color;
                const r = 3.5 * (1 - this.age / this.lifetime) + 1;
                ctx.beginPath(); ctx.arc(this.x, this.y, r, 0, Math.PI * 2); ctx.fill();
                break;
            }
            case 'speedLine':
                ctx.strokeStyle = this.color; ctx.lineWidth = 1;
                ctx.beginPath(); ctx.moveTo(this.x, this.y); ctx.lineTo(this.x - 30, this.y); ctx.stroke();
                break;
        }
        ctx.restore();
    }
}

class Collision {
    static aabb(a, b) {
        return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
    }
    checkPlayerZombies(player, zombies) {
        if (!player || player._invulTimer > 0 || player._respawning ||
            player.state === PlayerState.HIT || player.state === PlayerState.GAME_OVER ||
            player.isEliminated) {
            return null;
        }
        const ph = player.hitbox;
        for (const z of zombies) {
            if (z.isOffscreen) continue;
            const zh = z.hitbox;
            if (!Collision.aabb(ph, zh)) continue;
            // Se o jogador estiver balançando bem alto por cima do inimigo, não toma dano
            if (player.state === PlayerState.SWINGING && ph.y + ph.h <= zh.y - 15) continue;
            return z;
        }
        return null;
    }

    checkPlayerCoins(player, coins, playerTag = 'solo') {
        if (!player || player.state === PlayerState.HIT || player.state === PlayerState.GAME_OVER || player.isEliminated) {
            return [];
        }
        const ph = player.hitbox;
        const collected = [];
        for (const c of coins) {
            if (c.isOffscreen) continue;
            if (playerTag === 'p1' && c.collectedByP1) continue;
            if (playerTag === 'p2' && c.collectedByP2) continue;
            if (playerTag === 'solo' && (c.collectedByP1 || c.collectedByP2)) continue;

            const ch = c.getHitbox(player.groundY);
            if (Collision.aabb(ph, ch)) {
                collected.push(c);
            }
        }
        return collected;
    }

    checkPlayerPotions(player, potions, playerTag = 'solo') {
        if (!player || player.state === PlayerState.HIT || player.state === PlayerState.GAME_OVER || player.isEliminated) {
            return null;
        }
        const ph = player.hitbox;
        for (const p of potions) {
            if (p.isOffscreen) continue;
            if (p.targetPlayer !== playerTag) continue;

            const pth = p.getHitbox(player.groundY);
            if (Collision.aabb(ph, pth)) {
                return p;
            }
        }
        return null;
    }
}

// ---------------------------------------------------------------------------
// UI — interface moderna e responsiva para qualquer tamanho de tela
// ---------------------------------------------------------------------------

class UI {
    constructor(canvas) {
        this.canvas = canvas;
        this.soloBtn      = null;
        this.duplaBtn     = null;
        this.startBtn     = null;
        this.howToPlayBtn = null;
        this.backBtn      = null;
        this.playAgainBtn = null;
        this.menuBtn      = null;
        this.muteBtn      = null;
        this.resumeBtn    = null;
        this.restartBtn   = null;
        this.pauseMenuBtn = null;
    }

    _roundRect(ctx, x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
    }

    _drawButton(ctx, label, x, y, w, h, accent) {
        this._roundRect(ctx, x, y, w, h, 12);
        ctx.fillStyle = accent || 'rgba(255,255,255,0.14)';
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.55)';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        const fontSize = Math.max(14, Math.min(22, Math.round(h * 0.42)));
        ctx.font = `bold ${fontSize}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(label, x + w / 2, y + h / 2);
        return { x, y, w, h };
    }

    drawStartScreen(ctx, W, H, totalCoins = 0) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.78)';
        ctx.fillRect(0, 0, W, H);

        // Banco total de moedas no canto superior
        ctx.fillStyle = '#ffd700';
        ctx.font = 'bold 16px monospace';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        ctx.fillText(`🪙 ${totalCoins}`, W - 60, 24);

        const titleSize = Math.max(28, Math.min(68, Math.round(W * 0.052)));
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${titleSize}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🕸️ TEIA & SOBREVIVÊNCIA', W / 2, H * 0.26);

        const subSize = Math.max(14, Math.min(24, Math.round(titleSize * 0.42)));
        ctx.font = `${subSize}px sans-serif`;
        ctx.fillStyle = '#aaaacc';
        ctx.fillText('Balance pelos prédios. Desvie dos duendes. Colete moedas.', W / 2, H * 0.36);

        const btnW = Math.min(320, W * 0.7);
        const btnH = Math.min(58, Math.max(46, H * 0.08));
        const btnX = (W - btnW) / 2;

        this.startBtn     = this._drawButton(ctx, '▶  COMEÇAR', btnX, H * 0.48, btnW, btnH, 'rgba(239,83,80,0.35)');
        this.howToPlayBtn = this._drawButton(ctx, '❓ COMO JOGAR', btnX, H * 0.60, btnW, btnH);
    }

    drawModeSelect(ctx, W, H, totalCoins = 0) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.84)';
        ctx.fillRect(0, 0, W, H);

        // Banco total de moedas no canto superior
        ctx.fillStyle = '#ffd700';
        ctx.font = 'bold 16px monospace';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        ctx.fillText(`🪙 ${totalCoins}`, W - 60, 24);

        const titleSize = Math.max(24, Math.min(48, Math.round(W * 0.038)));
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${titleSize}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('ESCOLHA O MODO DE JOGO', W / 2, H * 0.16);

        const cardW = Math.min(360, (W - 80) / 2);
        const cardH = Math.min(320, H * 0.52);
        const gap   = Math.min(40, W * 0.04);
        const totalW = cardW * 2 + gap;
        const card1X = (W - totalW) / 2;
        const card2X = card1X + cardW + gap;
        const cardY  = H * 0.25;

        // Card SOLO
        this._roundRect(ctx, card1X, cardY, cardW, cardH, 16);
        ctx.fillStyle = 'rgba(239,83,80,0.18)'; ctx.fill();
        ctx.strokeStyle = 'rgba(239,83,80,0.7)'; ctx.lineWidth = 3; ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = `${Math.round(cardH * 0.22)}px sans-serif`;
        ctx.fillText('🕷️', card1X + cardW / 2, cardY + cardH * 0.24);
        ctx.font = `bold ${Math.max(16, Math.round(cardH * 0.09))}px sans-serif`;
        ctx.fillText('JOGAR SOZINHO', card1X + cardW / 2, cardY + cardH * 0.48);
        ctx.font = `${Math.max(11, Math.round(cardH * 0.055))}px sans-serif`;
        ctx.fillStyle = '#ccccee';
        ctx.fillText('Setas para mover / pular', card1X + cardW / 2, cardY + cardH * 0.60);
        ctx.fillText('Segure ↑ ou Espaço para teia', card1X + cardW / 2, cardY + cardH * 0.69);

        const btnH = Math.min(48, cardH * 0.18);
        this.soloBtn = this._drawButton(ctx, '▶  SOLO', card1X + cardW * 0.1, cardY + cardH - btnH - 12, cardW * 0.8, btnH, 'rgba(239,83,80,0.4)');

        // Card DUPLA
        this._roundRect(ctx, card2X, cardY, cardW, cardH, 16);
        ctx.fillStyle = 'rgba(255,213,79,0.18)'; ctx.fill();
        ctx.strokeStyle = 'rgba(255,213,79,0.7)'; ctx.lineWidth = 3; ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = `${Math.round(cardH * 0.22)}px sans-serif`;
        ctx.fillText('🕷️🕷️', card2X + cardW / 2, cardY + cardH * 0.24);
        ctx.font = `bold ${Math.max(16, Math.round(cardH * 0.09))}px sans-serif`;
        ctx.fillText('JOGAR EM DUPLA', card2X + cardW / 2, cardY + cardH * 0.48);
        ctx.font = `${Math.max(11, Math.round(cardH * 0.055))}px sans-serif`;
        ctx.fillStyle = '#ccccee';
        ctx.fillText('P1 (Cima): W, A, S, D', card2X + cardW / 2, cardY + cardH * 0.60);
        ctx.fillText('P2 (Baixo): Setas ← ↑ → ↓', card2X + cardW / 2, cardY + cardH * 0.69);

        this.duplaBtn = this._drawButton(ctx, '▶  DUPLA', card2X + cardW * 0.1, cardY + cardH - btnH - 12, cardW * 0.8, btnH, 'rgba(255,213,79,0.4)');

        // Botão Voltar
        const backW = Math.min(220, W * 0.4);
        const backH = Math.min(46, H * 0.07);
        this.backBtn = this._drawButton(ctx, '← VOLTAR', (W - backW) / 2, H * 0.85, backW, backH);
    }

    drawHowToPlay(ctx, W, H) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.90)';
        ctx.fillRect(0, 0, W, H);

        const titleSize = Math.max(22, Math.min(42, Math.round(W * 0.035)));
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${titleSize}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('❓ COMO JOGAR', W / 2, H * 0.10);

        const lines = [
            '🕸️ MODO SOLO: Use as SETAS do teclado para mover e pular.',
            'Segure SETA PARA CIMA (↑) ou ESPAÇO para disparar a teia nos prédios e balançar!',
            '',
            '👥 MODO DUPLA: Tela dividida em duas metades (P1 em cima, P2 embaixo).',
            '• Player 1 (Cima): W (Pular / Segure para Teia), A (Esquerda), S (Descer), D (Direita).',
            '• Player 2 (Baixo): ↑ (Pular / Segure para Teia), ← (Esquerda), ↓ (Descer), → (Direita).',
            '',
            '🪙 MOEDAS DE RECOMPENSA:',
            'Colete moedas no chão e no ar durante os balanços para somar pontos e acumular tesouro!',
            '',
            '🧪 POÇÃO VENOM (A cada 2500 pontos):',
            'Pegue a poção para alternar com o Venom. Como Venom, todos os pontos valem em dobro (x2)!',
        ];

        const lineSize = Math.max(11, Math.min(17, Math.round(H * 0.026)));
        ctx.font = `${lineSize}px sans-serif`;
        ctx.fillStyle = '#ddeeff';

        const startY = H * 0.18;
        const lineSpacing = Math.min(32, (H * 0.65) / lines.length);
        lines.forEach((line, i) => {
            if (line.startsWith('•') || line.startsWith('🕸️') || line.startsWith('👥') || line.startsWith('🪙')) {
                ctx.fillStyle = '#ffffff';
                ctx.font = `bold ${lineSize}px sans-serif`;
            } else {
                ctx.fillStyle = '#bbccdd';
                ctx.font = `${lineSize}px sans-serif`;
            }
            ctx.fillText(line, W / 2, startY + i * lineSpacing);
        });

        const backW = Math.min(220, W * 0.4);
        const backH = Math.min(46, H * 0.07);
        this.backBtn = this._drawButton(ctx, '← VOLTAR', (W - backW) / 2, H * 0.88, backW, backH);
    }

    drawHUD(ctx, W, H, score, highScore, tierName, tierTimer, gameMode, player, coinsCollected = 0) {
        const hudH = Math.max(34, Math.round(H * 0.065));

        // Barra superior translúcida
        ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
        ctx.fillRect(0, 0, W, hudH);

        const fs = Math.max(13, Math.round(hudH * 0.45));
        const midY = hudH / 2;

        // Pontuação e Moedas à esquerda
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${fs}px monospace`;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(`PONTOS: ${String(score).padStart(6, '0')}`, 16, midY);

        // Contador de moedas coletadas
        ctx.fillStyle = '#ffd700';
        ctx.fillText(`🪙 ${String(coinsCollected).padStart(3, '0')}`, 215, midY);

        // Indicador de Transformação Venom (x2)
        if (player && player.isVenom) {
            ctx.fillStyle = '#e1bee7';
            ctx.font = `bold ${fs}px sans-serif`;
            ctx.fillText('⚡ VENOM (x2)', 310, midY);
        }

        // Recorde ao centro
        ctx.fillStyle = '#ffcc44';
        ctx.textAlign = 'center';
        ctx.font = `bold ${fs}px monospace`;
        ctx.fillText(`RECORDE: ${String(highScore).padStart(6, '0')}`, W / 2, midY);

        // Vidas / Corações à direita (posicionados antes do botão de som para não sobrepor)
        ctx.textAlign = 'right';
        ctx.font = `${fs}px sans-serif`;
        const lv = player ? player.lives : 3;
        let ht = '';
        for (let k = 0; k < 3; k++) ht += (k < lv) ? '❤️' : '🖤';
        ctx.fillText(ht, W - 60, midY);

        // Notificação de Dificuldade
        if (tierTimer > 0) {
            const alpha = Math.min(1, tierTimer / 500);
            ctx.globalAlpha = alpha;
            ctx.fillStyle = '#ffffff';
            ctx.font = `bold ${Math.max(20, Math.round(H * 0.05))}px sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(tierName, W / 2, hudH + 40);
            ctx.globalAlpha = 1;
        }
    }

    drawMuteButton(ctx, W, H, muted, isDuo = false) {
        const label = muted ? '🔇' : '🔊';
        const size = isDuo ? 24 : 30;
        const btnX = W - (isDuo ? 42 : 48);
        const btnY = isDuo ? 4 : 8;
        const btnW = isDuo ? 36 : 40;
        const btnH = isDuo ? 24 : 32;

        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        this._roundRect(ctx, btnX, btnY, btnW, btnH, 6);
        ctx.fill();

        ctx.font = `${size * 0.65}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#ffffff';
        ctx.fillText(label, btnX + btnW / 2, btnY + btnH / 2);
        ctx.restore();

        this.muteBtn = { x: btnX, y: btnY, w: btnW, h: btnH };
    }

    drawPause(ctx, W, H) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
        ctx.fillRect(0, 0, W, H);

        const titleSize = Math.max(26, Math.min(54, Math.round(H * 0.08)));
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${titleSize}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('⏸ PAUSADO', W / 2, H * 0.28);

        const btnW = Math.min(280, W * 0.6);
        const btnH = Math.min(52, Math.max(42, H * 0.075));
        const btnX = (W - btnW) / 2;

        this.resumeBtn    = this._drawButton(ctx, '▶  CONTINUAR', btnX, H * 0.42, btnW, btnH, 'rgba(76,175,80,0.35)');
        this.restartBtn   = this._drawButton(ctx, '🔄 REINICIAR',  btnX, H * 0.54, btnW, btnH);
        this.pauseMenuBtn = this._drawButton(ctx, '🏠 MENU',       btnX, H * 0.66, btnW, btnH);
    }

    drawGameOver(ctx, W, H, score, highScore, gameMode, p1Score, p2Score, coinsCollected = 0, p1Coins = 0, p2Coins = 0, totalCoins = 0) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
        ctx.fillRect(0, 0, W, H);

        const titleSize = Math.max(32, Math.min(72, Math.round(H * 0.11)));
        ctx.fillStyle = '#ff4444';
        ctx.font = `bold ${titleSize}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('GAME OVER', W / 2, H * 0.18);

        ctx.font = `bold ${Math.max(18, Math.round(H * 0.045))}px monospace`;
        ctx.fillStyle = '#ffcc44';
        ctx.fillText(`PONTUAÇÃO: ${String(score).padStart(6, '0')}`, W / 2, H * 0.29);

        ctx.fillStyle = '#aaaacc';
        ctx.font = `${Math.max(14, Math.round(H * 0.035))}px monospace`;
        ctx.fillText(`RECORDE: ${String(highScore).padStart(6, '0')}`, W / 2, H * 0.35);

        // Exibição de moedas da partida e acumuladas
        ctx.font = `bold ${Math.max(15, Math.round(H * 0.036))}px monospace`;
        ctx.fillStyle = '#ffd700';
        if (gameMode === GameMode.DUPLA) {
            ctx.fillText(`🪙 MOEDAS DA PARTIDA: ${coinsCollected} (P1: ${p1Coins} | P2: ${p2Coins})`, W / 2, H * 0.41);
        } else {
            ctx.fillText(`🪙 MOEDAS COLETADAS: ${coinsCollected}`, W / 2, H * 0.41);
        }

        ctx.font = `${Math.max(13, Math.round(H * 0.030))}px monospace`;
        ctx.fillStyle = '#ffe082';
        ctx.fillText(`💰 BANCO TOTAL: ${totalCoins} moedas`, W / 2, H * 0.46);

        const btnW = Math.min(300, W * 0.65);
        const btnH = Math.min(54, Math.max(42, H * 0.075));
        const btnX = (W - btnW) / 2;

        this.playAgainBtn = this._drawButton(ctx, '▶  JOGAR NOVAMENTE', btnX, H * 0.54, btnW, btnH, 'rgba(239,83,80,0.35)');
        this.menuBtn      = this._drawButton(ctx, '🏠 VOLTAR AO MENU',  btnX, H * 0.66, btnW, btnH);
        this.howToPlayBtn = this._drawButton(ctx, '❓ COMO JOGAR',       btnX, H * 0.78, btnW, btnH);
    }

    drawCrosshair(ctx, mouseX, mouseY, isPlaying) {
        if (!isPlaying) return;
        ctx.save();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(mouseX, mouseY, 8, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(mouseX - 14, mouseY); ctx.lineTo(mouseX - 3, mouseY);
        ctx.moveTo(mouseX + 3, mouseY);  ctx.lineTo(mouseX + 14, mouseY);
        ctx.moveTo(mouseX, mouseY - 14); ctx.lineTo(mouseX, mouseY - 3);
        ctx.moveTo(mouseX, mouseY + 3);  ctx.lineTo(mouseX, mouseY + 14);
        ctx.stroke();
        ctx.restore();
    }

    hitTest(lx, ly, btn) {
        if (!btn) return false;
        return lx >= btn.x && lx <= btn.x + btn.w && ly >= btn.y && ly <= btn.y + btn.h;
    }
}

// ---------------------------------------------------------------------------
// Game — controlador principal
// ---------------------------------------------------------------------------

class Game {
    static MAX_ZOMBIES   = 50;
    static MAX_PARTICLES = 200;
    static DELTA_CAP     = 50;

    constructor(canvas) {
        this.canvas = canvas;
        this.ctx    = canvas.getContext('2d');
        this.paused     = false;
        this.gameScreen = 'start'; // start | modeselect | howtoplay | playing | paused | gameover
        this.gameMode   = GameMode.SOLO;

        this.score     = 0;
        this.highScore = parseInt(safeLSGet('webSwingHighScore', '0'), 10) || 0;
        this.totalCoins = parseInt(safeLSGet('webSwingTotalCoins', '0'), 10) || 0;
        this.coinsCollected = 0;
        this.p1Coins = 0;
        this.p2Coins = 0;
        this.distAccum = 0;

        this.currentTier      = DIFFICULTY_TIERS[0];
        this.scrollSpeed      = DIFFICULTY_TIERS[0].scrollSpeed;
        this.spawnInterval    = DIFFICULTY_TIERS[0].spawnInterval;
        this.spawnTimer       = 0;
        this.coinSpawnTimer   = 0;
        this.coinSpawnInterval = 2100;
        this.tierDisplayTimer = 0;
        this.shakeTimer       = 0;
        this.lastFrameTime    = 0;

        this.input      = new Input(canvas);
        this.audio      = new AudioSystem();
        this.background = new Background();
        this.ui         = new UI(canvas);
        this.collision  = new Collision();

        this.player1 = null;
        this.player2 = null;

        this.p1ScoreAtDeath = 0;
        this.p2ScoreAtDeath = 0;

        this.zombiePool   = Array.from({ length: Game.MAX_ZOMBIES },   () => new Zombie());
        this.coinPool     = Array.from({ length: 40 },                 () => new Coin());
        this.potionPool   = Array.from({ length: 6 },                  () => new Potion());
        this.particlePool = Array.from({ length: Game.MAX_PARTICLES }, () => new Particle());

        this._swingStartZombies1 = [];
        this._swingStartZombies2 = [];

        // Marcos de pontuação para aparecimento de poções a cada 2500 pontos
        this._nextSoloPotionScore = 2500;
        this._nextP1PotionScore   = 2500;
        this._nextP2PotionScore   = 2500;

        // Hold timers para pulo vs teia
        this._p1WHoldMs   = 0;
        this._p1WHeld     = false;
        this._p1WebActive = false;

        this._p2UpHoldMs   = 0;
        this._p2UpHeld     = false;
        this._p2WebActive  = false;

        this._soloUpHoldMs   = 0;
        this._soloUpHeld     = false;
        this._soloWebActive  = false;

        this._onKeyDown = (e) => {
            if ((e.code === 'Escape' || e.code === 'KeyP') && this.gameScreen === 'playing') {
                this.gameScreen = 'paused'; this.paused = true;
            } else if ((e.code === 'Escape' || e.code === 'KeyP') && this.gameScreen === 'paused') {
                this.gameScreen = 'playing'; this.paused = false;
            }
        };
        window.addEventListener('keydown', this._onKeyDown);

        this._onCanvasClick = this._handleCanvasClick.bind(this);
        canvas.addEventListener('click',    this._onCanvasClick);
        canvas.addEventListener('touchend', this._onCanvasClick, { passive: false });

        this.audio.load([
            { name: 'webShoot',    path: '../assets/sounds/web_shoot.mp3' },
            { name: 'webAttach',   path: '../assets/sounds/web_attach.mp3' },
            { name: 'swingWhoosh', path: '../assets/sounds/swing_whoosh.mp3' },
            { name: 'landing',     path: '../assets/sounds/landing.mp3' },
            { name: 'hit',         path: '../assets/sounds/hit.mp3' },
            { name: 'zombieGroan', path: '../assets/sounds/zombie_groan.mp3' },
            { name: 'gameOver',    path: '../assets/sounds/game_over.mp3' },
        ]);

        this._tickBound = this.tick.bind(this);
    }

    _fireWebTo(player, targetX, targetY) {
        if (!player) return;
        if (player.state !== PlayerState.RUNNING && player.state !== PlayerState.FALLING &&
            player.state !== PlayerState.JUMPING) return;
        if (player.web) return;

        const clampedY = Math.min(targetY, player.centerY - 35);
        player.web   = new Web(player, targetX, clampedY);
        player.state = PlayerState.WEB_SHOOTING;
        this.audio.play('webShoot');
    }

    resizeCanvas() {
        const W = window.innerWidth;
        const H = window.innerHeight;
        this.canvas.width  = W;
        this.canvas.height = H;

        // Atualiza a posição do chão dos jogadores conforme o modo
        const soloGround = Math.round(H * 0.82);
        const duoGround  = Math.max(120, Math.round(H / 2 - 32));

        if (this.gameMode === GameMode.SOLO) {
            if (this.player1) this.player1.groundY = soloGround;
        } else {
            if (this.player1) this.player1.groundY = duoGround;
            if (this.player2) this.player2.groundY = duoGround;
        }
    }

    start() {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.paused = true;
            } else {
                this.lastFrameTime = performance.now();
                this.paused = false;
            }
        });
        requestAnimationFrame(this._tickBound);
    }

    startGameplay() {
        this.resizeCanvas();
        this.score = 0; this.distAccum = 0; this.spawnTimer = 0;
        this.coinsCollected = 0;
        this.p1Coins = 0;
        this.p2Coins = 0;
        this.coinSpawnTimer = 0;
        this._nextSoloPotionScore = 2500;
        this._nextP1PotionScore   = 2500;
        this._nextP2PotionScore   = 2500;
        this.shakeTimer = 0; this.tierDisplayTimer = 0;
        this.currentTier   = DIFFICULTY_TIERS[0];
        this.scrollSpeed   = DIFFICULTY_TIERS[0].scrollSpeed;
        this.spawnInterval = DIFFICULTY_TIERS[0].spawnInterval;
        this._swingStartZombies1 = [];
        this._swingStartZombies2 = [];
        this.p1ScoreAtDeath = 0;
        this.p2ScoreAtDeath = 0;

        for (const z of this.zombiePool)   z.isOffscreen = true;
        for (const c of this.coinPool)     c.isOffscreen = true;
        for (const p of this.potionPool)   p.isOffscreen = true;
        for (const p of this.particlePool) p.isDead = true;

        const W = this.canvas.width;
        const H = this.canvas.height;
        const groundY = this.gameMode === GameMode.SOLO ? Math.round(H * 0.82) : Math.max(120, Math.round(H / 2 - 32));

        this.player1 = new Player(Math.round(W * 0.16), 0, groundY);
        this.player2 = this.gameMode === GameMode.DUPLA ? new Player(Math.round(W * 0.26), 1, groundY) : null;

        this._p1WHoldMs   = 0; this._p1WHeld   = false; this._p1WebActive = false;
        this._p2UpHoldMs  = 0; this._p2UpHeld  = false; this._p2WebActive = false;
        this._soloUpHoldMs= 0; this._soloUpHeld= false; this._soloWebActive = false;

        this.input.setGameActive(true);
        this.gameScreen = 'playing';
        this.paused = false;
    }

    tick(timestamp) {
        const rawDt = this.lastFrameTime === 0 ? 0 : timestamp - this.lastFrameTime;
        const dt    = Math.min(rawDt, Game.DELTA_CAP);
        this.lastFrameTime = timestamp;

        if (!this.paused) this.update(dt);
        this.render();
        requestAnimationFrame(this._tickBound);
    }

    update(dt) {
        this.input.processFrame();

        const bgSpeed = this.gameScreen === 'playing' ? this.scrollSpeed : DIFFICULTY_TIERS[0].scrollSpeed;
        this.background.update(bgSpeed, dt);

        if (this.gameScreen !== 'playing') return;

        const dtS = dt / 1000;
        const scrollPx = this.scrollSpeed * 60 * dtS;
        const W = this.canvas.width;
        const H = this.canvas.height;

        // =========================================================================
        // MODO SOLO: Controle por SETAS (↑ toque=pulo, segurar=teia) + Espaço / Mouse
        // =========================================================================
        if (this.gameMode === GameMode.SOLO && this.player1 && !this.player1.isEliminated) {
            const p1 = this.player1;

            // Segurar Seta para Cima (↑) ou Espaço dispara teia no Solo
            const isUpOrSpace = this.input.solo.up || this.input.solo.spaceHeld;

            if (isUpOrSpace) {
                if (!this._soloUpHeld) {
                    this._soloUpHeld = true;
                    this._soloUpHoldMs = 0;
                    this._soloWebActive = false;
                }
                this._soloUpHoldMs += dt;
                if (this._soloUpHoldMs >= 160 && !this._soloWebActive && !p1.web) {
                    this._soloWebActive = true;
                    // Âncora acima e à frente para balanço em "A"
                    this._fireWebTo(p1, p1.centerX + 230, Math.max(30, p1.centerY - 280));
                }
            } else {
                if (this._soloUpHeld) {
                    if (this._soloWebActive) {
                        if (p1.state === PlayerState.SWINGING) {
                            p1.releaseWeb();
                            this._checkSwingBonus(p1, this._swingStartZombies1);
                        } else if (p1.state === PlayerState.WEB_SHOOTING) {
                            p1.cancelWeb();
                        }
                    }
                    this._soloUpHeld = false;
                    this._soloWebActive = false;
                    this._soloUpHoldMs = 0;
                }
            }

            // Mira com mouse no Solo
            if (this.input.mouseJustDown) {
                if (this.input.mouseY < p1.centerY - 20) {
                    this._fireWebTo(p1, this.input.mouseX, this.input.mouseY);
                    this._soloWebActive = true;
                }
            }
            if (this.input.mouseJustUp && this._soloWebActive) {
                if (p1.state === PlayerState.SWINGING) {
                    p1.releaseWeb();
                    this._checkSwingBonus(p1, this._swingStartZombies1);
                } else if (p1.state === PlayerState.WEB_SHOOTING) {
                    p1.cancelWeb();
                }
                this._soloWebActive = false;
            }

            const ctrlSolo = {
                left:  this.input.solo.left,
                right: this.input.solo.right,
                down:  this.input.solo.down,
                jumpJustPressed:  this.input.solo.jumpJustPressed && this._soloUpHoldMs < 160,
                jumpJustReleased: false,
                webJustPressed:   false,
                webJustReleased:  false,
            };

            const prevP1State = p1.state;
            p1.update(dt, ctrlSolo, W);

            if (p1.web) p1.web.scrollAnchor(scrollPx);
            if (p1.web) {
                const prevTaut = p1.web.isTaut;
                p1.web.update(dt, p1, ctrlSolo, W);
                if (!p1.web.isTaut && p1.web._travelTimer > 400) {
                    p1.cancelWeb(); this._soloWebActive = false;
                } else if (!prevTaut && p1.web && p1.web.isTaut) {
                    p1.startSwinging();
                    this.audio.play('webAttach');
                    this._swingStartZombies1 = this.zombiePool.filter(z => !z.isOffscreen);
                    this._emitSilk(p1);
                }
            }

            if (p1._forceReleaseWeb) {
                p1.releaseWeb();
                this._checkSwingBonus(p1, this._swingStartZombies1);
                this._soloWebActive = false;
            }

            if (prevP1State === PlayerState.FALLING && p1.state === PlayerState.RUNNING) {
                this._emitDust(p1.centerX, p1.groundY);
                this.audio.play('landing');
            }

            const spd1 = Math.sqrt(p1.vx ** 2 + p1.vy ** 2);
            if ((p1.state === PlayerState.SWINGING || p1.state === PlayerState.FALLING) && spd1 > 220) {
                if (Math.random() < 0.35) this._emitSpeedLines(p1);
            }

            if (p1._needsRespawn) {
                p1._needsRespawn = false;
                const spawnX = Math.round(W * 0.16);
                this._clearSafeZone(spawnX, 480);
                p1.respawn(spawnX);
                this._soloUpHeld = false; this._soloWebActive = false; this._soloUpHoldMs = 0;
            }
        }

        // =========================================================================
        // MODO DUPLA: P1 usa WASD (W=pulo/teia) | P2 usa Setas (↑=pulo/teia)
        // =========================================================================
        if (this.gameMode === GameMode.DUPLA) {
            // ---- PLAYER 1 (WASD) ----
            if (this.player1 && !this.player1.isEliminated) {
                const p1 = this.player1;

                if (this.input.p1.up) {
                    if (!this._p1WHeld) {
                        this._p1WHeld = true;
                        this._p1WHoldMs = 0;
                        this._p1WebActive = false;
                    }
                    this._p1WHoldMs += dt;
                    if (this._p1WHoldMs >= 160 && !this._p1WebActive && !p1.web) {
                        this._p1WebActive = true;
                        this._fireWebTo(p1, p1.centerX + 220, Math.max(20, p1.centerY - 220));
                    }
                } else {
                    if (this._p1WHeld) {
                        if (this._p1WebActive) {
                            if (p1.state === PlayerState.SWINGING) {
                                p1.releaseWeb();
                                this._checkSwingBonus(p1, this._swingStartZombies1);
                            } else if (p1.state === PlayerState.WEB_SHOOTING) {
                                p1.cancelWeb();
                            }
                        }
                        this._p1WHeld = false;
                        this._p1WebActive = false;
                        this._p1WHoldMs = 0;
                    }
                }

                const ctrlP1 = {
                    left:  this.input.p1.left,
                    right: this.input.p1.right,
                    down:  this.input.p1.down,
                    jumpJustPressed:  this.input.p1.jumpJustPressed && this._p1WHoldMs < 160,
                    jumpJustReleased: false,
                    webJustPressed:   false,
                    webJustReleased:  false,
                };

                const prevP1State = p1.state;
                p1.update(dt, ctrlP1, W);

                if (p1.web) p1.web.scrollAnchor(scrollPx);
                if (p1.web) {
                    const prevTaut = p1.web.isTaut;
                    p1.web.update(dt, p1, ctrlP1, W);
                    if (!p1.web.isTaut && p1.web._travelTimer > 400) {
                        p1.cancelWeb(); this._p1WebActive = false;
                    } else if (!prevTaut && p1.web && p1.web.isTaut) {
                        p1.startSwinging();
                        this.audio.play('webAttach');
                        this._swingStartZombies1 = this.zombiePool.filter(z => !z.isOffscreen);
                        this._emitSilk(p1);
                    }
                }

                if (p1._forceReleaseWeb) {
                    p1.releaseWeb();
                    this._checkSwingBonus(p1, this._swingStartZombies1);
                    this._p1WebActive = false;
                }

                if (prevP1State === PlayerState.FALLING && p1.state === PlayerState.RUNNING) {
                    this._emitDust(p1.centerX, p1.groundY);
                    this.audio.play('landing');
                }

                if (p1._needsRespawn) {
                    p1._needsRespawn = false;
                    const spawnX = Math.round(W * 0.16);
                    this._clearSafeZone(spawnX, 480);
                    p1.respawn(spawnX);
                    this._p1WHeld = false; this._p1WebActive = false; this._p1WHoldMs = 0;
                }
            }

            // ---- PLAYER 2 (SETAS) ----
            if (this.player2 && !this.player2.isEliminated) {
                const p2 = this.player2;

                if (this.input.p2.up) {
                    if (!this._p2UpHeld) {
                        this._p2UpHeld = true;
                        this._p2UpHoldMs = 0;
                        this._p2WebActive = false;
                    }
                    this._p2UpHoldMs += dt;
                    if (this._p2UpHoldMs >= 160 && !this._p2WebActive && !p2.web) {
                        this._p2WebActive = true;
                        this._fireWebTo(p2, p2.centerX + 220, Math.max(20, p2.centerY - 220));
                    }
                } else {
                    if (this._p2UpHeld) {
                        if (this._p2WebActive) {
                            if (p2.state === PlayerState.SWINGING) {
                                p2.releaseWeb();
                                this._checkSwingBonus(p2, this._swingStartZombies2);
                            } else if (p2.state === PlayerState.WEB_SHOOTING) {
                                p2.cancelWeb();
                            }
                        }
                        this._p2UpHeld = false;
                        this._p2WebActive = false;
                        this._p2UpHoldMs = 0;
                    }
                }

                const ctrlP2 = {
                    left:  this.input.p2.left,
                    right: this.input.p2.right,
                    down:  this.input.p2.down,
                    jumpJustPressed:  this.input.p2.jumpJustPressed && this._p2UpHoldMs < 160,
                    jumpJustReleased: false,
                    webJustPressed:   false,
                    webJustReleased:  false,
                };

                const prevP2State = p2.state;
                p2.update(dt, ctrlP2, W);

                if (p2.web) p2.web.scrollAnchor(scrollPx);
                if (p2.web) {
                    const prevTaut = p2.web.isTaut;
                    p2.web.update(dt, p2, ctrlP2, W);
                    if (!p2.web.isTaut && p2.web._travelTimer > 400) {
                        p2.cancelWeb(); this._p2WebActive = false;
                    } else if (!prevTaut && p2.web && p2.web.isTaut) {
                        p2.startSwinging();
                        this.audio.play('webAttach');
                        this._swingStartZombies2 = this.zombiePool.filter(z => !z.isOffscreen);
                        this._emitSilk(p2);
                    }
                }

                if (p2._forceReleaseWeb) {
                    p2.releaseWeb();
                    this._checkSwingBonus(p2, this._swingStartZombies2);
                    this._p2WebActive = false;
                }

                if (prevP2State === PlayerState.FALLING && p2.state === PlayerState.RUNNING) {
                    this._emitDust(p2.centerX, p2.groundY);
                    this.audio.play('landing');
                }

                if (p2._needsRespawn) {
                    p2._needsRespawn = false;
                    const spawnX = Math.round(W * 0.26);
                    this._clearSafeZone(spawnX, 480);
                    p2.respawn(spawnX);
                    this._p2UpHeld = false; this._p2WebActive = false; this._p2UpHoldMs = 0;
                }
            }
        }

        // Spawning de duendes
        this.spawnTimer += dt;
        if (this.spawnTimer >= this.spawnInterval) {
            this.spawnTimer = 0;
            this._spawnZombie(W);
        }
        for (const z of this.zombiePool) if (!z.isOffscreen) z.update(dt, this.scrollSpeed);

        const currentGroundY = (this.gameMode === GameMode.SOLO)
            ? (this.player1 ? this.player1.groundY : Math.round(H * 0.82))
            : Math.max(120, Math.round(H / 2 - 32));

        // Spawning de moedas em arcos dinâmicos dentro de 80% do alcance real
        this.coinSpawnTimer += dt;
        if (this.coinSpawnTimer >= this.coinSpawnInterval) {
            this.coinSpawnTimer = 0;
            this._spawnCoins(W, currentGroundY);
        }
        for (const c of this.coinPool) if (!c.isOffscreen) c.update(dt, this.scrollSpeed);

        // Spawning de poção de transformação a cada 2500 pontos (Solo: score geral | Dupla: individual por jogador)
        if (this.gameMode === GameMode.SOLO) {
            if (this.score >= this._nextSoloPotionScore) {
                const milestone = this._nextSoloPotionScore;
                while (this.score >= this._nextSoloPotionScore) this._nextSoloPotionScore += 2500;
                this._spawnPotion(W, currentGroundY, 'solo', milestone);
            }
        } else if (this.gameMode === GameMode.DUPLA) {
            if (this.player1 && !this.player1.isEliminated && this.player1.score >= this._nextP1PotionScore) {
                const milestoneP1 = this._nextP1PotionScore;
                while (this.player1.score >= this._nextP1PotionScore) this._nextP1PotionScore += 2500;
                this._spawnPotion(W, currentGroundY, 'p1', milestoneP1);
            }
            if (this.player2 && !this.player2.isEliminated && this.player2.score >= this._nextP2PotionScore) {
                const milestoneP2 = this._nextP2PotionScore;
                while (this.player2.score >= this._nextP2PotionScore) this._nextP2PotionScore += 2500;
                this._spawnPotion(W, currentGroundY, 'p2', milestoneP2);
            }
        }
        for (const p of this.potionPool) if (!p.isOffscreen) p.update(dt, this.scrollSpeed);

        // Coleta de moedas — Modo SOLO (Pontos x2 se Venom)
        if (this.gameMode === GameMode.SOLO && this.player1 && !this.player1.isEliminated && this.player1.state !== PlayerState.GAME_OVER) {
            const coins1 = this.collision.checkPlayerCoins(this.player1, this.coinPool, 'solo');
            for (const c of coins1) {
                c.collectedByP1 = true;
                c.isOffscreen = true;
                this.coinsCollected++;
                this.totalCoins++;
                const mult = this.player1.isVenom ? 2 : 1;
                const pts = c.scoreBonus * mult;
                this.score += pts;
                this.player1.score += pts;
                this._emitCoinSparkles(c.x, this.player1.groundY - c.relY, 'all');
                this.audio.playCoin();
            }

            // Coleta de poção Solo (Alterna Homem-Aranha <-> Venom)
            const pot1 = this.collision.checkPlayerPotions(this.player1, this.potionPool, 'solo');
            if (pot1) {
                pot1.isOffscreen = true;
                this.player1.isVenom = !this.player1.isVenom;
                this._emitSymbioteBurst(pot1.x, this.player1.groundY - pot1.relY, 'all');
                this.audio.playTransformation();
            }
        }

        // Coleta de moedas e poções — Modo DUPLA (P1 e P2 independentes)
        if (this.gameMode === GameMode.DUPLA) {
            // Player 1
            if (this.player1 && !this.player1.isEliminated && this.player1.state !== PlayerState.GAME_OVER) {
                const coinsP1 = this.collision.checkPlayerCoins(this.player1, this.coinPool, 'p1');
                for (const c of coinsP1) {
                    c.collectedByP1 = true;
                    if (c.collectedByP2) c.isOffscreen = true;
                    this.p1Coins++;
                    this.coinsCollected++;
                    this.totalCoins++;
                    const mult = this.player1.isVenom ? 2 : 1;
                    const pts = c.scoreBonus * mult;
                    this.player1.score += pts;
                    this.score += pts;
                    this._emitCoinSparkles(c.x, this.player1.groundY - c.relY, 'p1');
                    this.audio.playCoin();
                }

                const potP1 = this.collision.checkPlayerPotions(this.player1, this.potionPool, 'p1');
                if (potP1) {
                    potP1.isOffscreen = true;
                    this.player1.isVenom = !this.player1.isVenom;
                    this._emitSymbioteBurst(potP1.x, this.player1.groundY - potP1.relY, 'p1');
                    this.audio.playTransformation();
                }
            }

            // Player 2
            if (this.player2 && !this.player2.isEliminated && this.player2.state !== PlayerState.GAME_OVER) {
                const coinsP2 = this.collision.checkPlayerCoins(this.player2, this.coinPool, 'p2');
                for (const c of coinsP2) {
                    c.collectedByP2 = true;
                    if (c.collectedByP1) c.isOffscreen = true;
                    this.p2Coins++;
                    this.coinsCollected++;
                    this.totalCoins++;
                    const mult = this.player2.isVenom ? 2 : 1;
                    const pts = c.scoreBonus * mult;
                    this.player2.score += pts;
                    this.score += pts;
                    this._emitCoinSparkles(c.x, this.player2.groundY - c.relY, 'p2');
                    this.audio.playCoin();
                }

                const potP2 = this.collision.checkPlayerPotions(this.player2, this.potionPool, 'p2');
                if (potP2) {
                    potP2.isOffscreen = true;
                    this.player2.isVenom = !this.player2.isVenom;
                    this._emitSymbioteBurst(potP2.x, this.player2.groundY - potP2.relY, 'p2');
                    this.audio.playTransformation();
                }
            }
        }


        // Colisões com inimigos
        if (this.player1 && !this.player1.isEliminated && this.player1.state !== PlayerState.GAME_OVER) {
            const hit1 = this.collision.checkPlayerZombies(this.player1, this.zombiePool);
            if (hit1) {
                // Elimina o duende que acertou o jogador imediatamente (desintegra com poeira)
                hit1.isOffscreen = true;
                this._emitDust(hit1.x + hit1.w / 2, hit1.y + hit1.h / 2);
                this.player1.takeDamage();
                this.shakeTimer = 400;
                this.audio.play('hit');
                this.p1ScoreAtDeath = this.score;
            }
        }
        if (this.player2 && !this.player2.isEliminated && this.player2.state !== PlayerState.GAME_OVER) {
            const hit2 = this.collision.checkPlayerZombies(this.player2, this.zombiePool);
            if (hit2) {
                // Elimina o duende que acertou o jogador imediatamente (desintegra com poeira)
                hit2.isOffscreen = true;
                this._emitDust(hit2.x + hit2.w / 2, hit2.y + hit2.h / 2);
                this.player2.takeDamage();
                this.shakeTimer = 400;
                this.audio.play('hit');
                this.p2ScoreAtDeath = this.score;
            }
        }

        // Verificação de Game Over
        const p1Dead = !this.player1 || this.player1.isEliminated || (this.player1.lives <= 0 && this.player1.state === PlayerState.HIT);
        const p2Dead = !this.player2 || this.player2.isEliminated || (this.player2.lives <= 0 && this.player2.state === PlayerState.HIT);
        const isGameOver = this.gameMode === GameMode.SOLO ? p1Dead : (p1Dead && p2Dead);

        if (isGameOver && this.gameScreen === 'playing') {
            this.gameScreen = 'gameover';
            this.input.setGameActive(false);
            if (this.score > this.highScore) {
                this.highScore = this.score;
                safeLSSet('webSwingHighScore', this.highScore);
            }
            safeLSSet('webSwingTotalCoins', this.totalCoins);
            this.audio.play('gameOver');
            return;
        }

        // Partículas
        for (const p of this.particlePool) if (!p.isDead) p.update(dt);

        // Pontuação baseada em avanço (multiplica por 2 se estiver como Venom)
        const isAdvancing = (this.player1 && !this.player1.isEliminated) ||
                            (this.player2 && !this.player2.isEliminated);
        if (isAdvancing) {
            this.distAccum += scrollPx;
            if (this.distAccum >= 10) {
                const basePts = Math.floor(this.distAccum / 10);
                this.distAccum = this.distAccum % 10;

                if (this.gameMode === GameMode.SOLO) {
                    const mult = (this.player1 && this.player1.isVenom) ? 2 : 1;
                    const pts = basePts * mult;
                    this.score += pts;
                    if (this.player1) this.player1.score += pts;
                } else {
                    let earnedP1 = 0;
                    let earnedP2 = 0;
                    if (this.player1 && !this.player1.isEliminated) {
                        earnedP1 = basePts * (this.player1.isVenom ? 2 : 1);
                        this.player1.score += earnedP1;
                    }
                    if (this.player2 && !this.player2.isEliminated) {
                        earnedP2 = basePts * (this.player2.isVenom ? 2 : 1);
                        this.player2.score += earnedP2;
                    }
                    this.score += Math.max(earnedP1, earnedP2);
                }
            }
        }

        // Dificuldade
        const newTier = getTierForScore(this.score);
        if (newTier.name !== this.currentTier.name) {
            this.currentTier   = newTier;
            this.scrollSpeed   = newTier.scrollSpeed;
            this.spawnInterval = newTier.spawnInterval;
            this.tierDisplayTimer = 2000;
        }
        if (this.tierDisplayTimer > 0) this.tierDisplayTimer = Math.max(0, this.tierDisplayTimer - dt);
        if (this.shakeTimer > 0)       this.shakeTimer       = Math.max(0, this.shakeTimer - dt);
    }

    _clearSafeZone(targetX, safeRadius = 480) {
        // Limpa quaisquer duendes próximos ao ponto de renascimento para nunca nascer relando neles
        for (const z of this.zombiePool) {
            if (!z.isOffscreen && (Math.abs(z.x - targetX) < safeRadius || z.x < targetX + safeRadius)) {
                z.isOffscreen = true;
            }
        }
        // Reseta o timer de spawn para dar tempo de preparação ao renascer
        this.spawnTimer = 0;
    }

    _spawnZombie(W) {
        const active = this.zombiePool.filter(z => !z.isOffscreen).length;
        if (active >= Game.MAX_ZOMBIES) return;

        let types;
        switch(this.currentTier.name) {
            case 'Easy':    types = ['common', 'common', 'common']; break;
            case 'Medium':  types = ['common', 'common', 'fast']; break;
            case 'Hard':    types = ['common', 'fast', 'large']; break;
            case 'Extreme': types = ['common', 'fast', 'fast', 'large']; break;
            default: types = ['common'];
        }

        const type = types[Math.floor(Math.random() * types.length)];
        const groundY = this.player1 ? this.player1.groundY : 600;
        const spawnX  = W + 60;

        if (Math.random() < 0.25 && type !== 'large') {
            const count = 2 + (Math.random() < 0.35 ? 1 : 0);
            for (let i = 0; i < count; i++) this._spawnOne(type, spawnX + i * 60, groundY);
        } else {
            this._spawnOne(type, spawnX, groundY);
        }
        this.audio.play('zombieGroan');
    }

    _spawnOne(type, x, groundY) {
        const free = this.zombiePool.find(z => z.isOffscreen);
        if (free) free.reset(type, x, this.scrollSpeed, groundY);
    }

    _spawnCoins(W, groundY) {
        const { minRelY, maxRelY } = getCoinHeightRange(groundY);
        const patternType = Math.random();
        const spawnX = W + 40;

        if (patternType < 0.55) {
            // Arco aéreo amplo e alto seguindo o balanço da teia até o topo
            const count = 5 + Math.floor(Math.random() * 3); // 5 a 7 moedas
            const peakRelY = minRelY + (maxRelY - minRelY) * (0.80 + Math.random() * 0.20);
            const spacing = 52;
            for (let i = 0; i < count; i++) {
                const t = i / (count - 1);
                // Parábola normalizada: 4 * t * (1 - t) varia de 0 nas pontas a 1 no ápice
                const arcRelY = minRelY + (peakRelY - minRelY) * (4 * t * (1 - t));
                this._spawnOneCoin(spawnX + i * spacing, Math.round(arcRelY));
            }
        } else if (patternType < 0.78) {
            // Fileira no nível do chão para corrida (3 a 5 moedas)
            const count = 3 + Math.floor(Math.random() * 3);
            for (let i = 0; i < count; i++) {
                this._spawnOneCoin(spawnX + i * 44, minRelY);
            }
        } else {
            // Linha aérea alta para pulos com teia (3 a 5 moedas)
            const count = 3 + Math.floor(Math.random() * 3);
            const midRelY = minRelY + (maxRelY - minRelY) * (0.55 + Math.random() * 0.35);
            for (let i = 0; i < count; i++) {
                this._spawnOneCoin(spawnX + i * 46, Math.round(midRelY));
            }
        }
    }

    _spawnOneCoin(x, relY) {
        const free = this.coinPool.find(c => c.isOffscreen);
        if (free) free.reset(x, relY);
    }

    _spawnPotion(W, groundY, targetPlayer, milestone) {
        // Se o jogador não pegou a poção anterior do mesmo alvo, a antiga some e aparece a nova
        for (const p of this.potionPool) {
            if (!p.isOffscreen && p.targetPlayer === targetPlayer) {
                p.isOffscreen = true;
            }
        }

        const free = this.potionPool.find(p => p.isOffscreen);
        if (!free) return;

        // Posiciona a poção numa altura e posição perfeitamente alcançáveis
        const { minRelY, maxRelY } = getCoinHeightRange(groundY);
        const reachableRelY = Math.round(minRelY + (maxRelY - minRelY) * 0.55);
        const spawnX = W + 60;

        free.reset(spawnX, reachableRelY, targetPlayer, milestone);
    }

    _emit(x, y, vx, vy, lifetime, color, kind, half = 'all') {
        const p = this.particlePool.find(p => p.isDead);
        if (p) p.init(x, y, vx, vy, lifetime, color, kind, half);
    }

    _emitSilk(player) {
        if (!player.web) return;
        for (let i = 0; i < 6; i++) {
            const t = i / 5;
            const px = player.centerX + (player.web.anchorX - player.centerX) * t;
            const py = player.centerY + (player.web.anchorY - player.centerY) * t;
            this._emit(px, py, (Math.random() - 0.5) * 80, (Math.random() - 0.5) * 80, 400, '#ccccff', 'silk');
        }
    }

    _emitDust(x, y) {
        for (let i = 0; i < 10; i++) {
            const a = Math.random() * Math.PI, s = 60 + Math.random() * 120;
            this._emit(x + (Math.random() - 0.5) * 20, y, Math.cos(a) * s, -Math.abs(Math.sin(a)) * s * 0.5, 300, '#aaaaaa', 'dust');
        }
    }

    _emitCoinSparkles(x, y, half = 'all') {
        const colors = ['#fff59d', '#ffd700', '#ffb300', '#ffffff'];
        for (let i = 0; i < 8; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 40 + Math.random() * 90;
            const color = colors[Math.floor(Math.random() * colors.length)];
            this._emit(
                x,
                y,
                Math.cos(angle) * speed,
                Math.sin(angle) * speed - 20,
                350,
                color,
                'coinSparkle',
                half
            );
        }
    }

    _emitSymbioteBurst(x, y, half = 'all') {
        const colors = ['#e1bee7', '#ba68c8', '#ab47bc', '#7b1fa2', '#ffffff', '#212121'];
        for (let i = 0; i < 20; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 60 + Math.random() * 160;
            const color = colors[Math.floor(Math.random() * colors.length)];
            this._emit(
                x,
                y,
                Math.cos(angle) * speed,
                Math.sin(angle) * speed - 25,
                500,
                color,
                'symbioteSparkle',
                half
            );
        }
    }

    _emitSpeedLines(player) {
        for (let i = 0; i < 3; i++) {
            this._emit(player.centerX - 10, player.centerY + (Math.random() - 0.5) * 30,
                -400 - Math.random() * 200, 0, 120, 'rgba(255,255,255,0.35)', 'speedLine');
        }
    }

    _checkSwingBonus(player, startZombies) {
        if (!player) return;
        const mult = player.isVenom ? 2 : 1;
        for (const z of startZombies) {
            if (z.isOffscreen) continue;
            const ph = player.hitbox, zh = z.hitbox;
            if (ph.y + ph.h <= zh.y - 15) {
                const bonus = 50 * mult;
                this.score += bonus;
                player.score += bonus;
            }
        }
    }

    _handleCanvasClick(e) {
        e.preventDefault();
        const rect = this.canvas.getBoundingClientRect();
        const clientX = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
        const clientY = e.changedTouches ? e.changedTouches[0].clientY : e.clientY;
        const lx = (clientX - rect.left) * (this.canvas.width / rect.width);
        const ly = (clientY - rect.top)  * (this.canvas.height / rect.height);

        if (this.gameScreen === 'start') {
            if      (this.ui.hitTest(lx, ly, this.ui.startBtn))     this.gameScreen = 'modeselect';
            else if (this.ui.hitTest(lx, ly, this.ui.howToPlayBtn)) this.gameScreen = 'howtoplay';
            else if (this.ui.hitTest(lx, ly, this.ui.muteBtn))      this.audio.toggleMute();
        } else if (this.gameScreen === 'modeselect') {
            if      (this.ui.hitTest(lx, ly, this.ui.soloBtn))  { this.gameMode = GameMode.SOLO;  this.startGameplay(); }
            else if (this.ui.hitTest(lx, ly, this.ui.duplaBtn)) { this.gameMode = GameMode.DUPLA; this.startGameplay(); }
            else if (this.ui.hitTest(lx, ly, this.ui.backBtn))  this.gameScreen = 'start';
            else if (this.ui.hitTest(lx, ly, this.ui.muteBtn))  this.audio.toggleMute();
        } else if (this.gameScreen === 'howtoplay') {
            if (this.ui.hitTest(lx, ly, this.ui.backBtn)) this.gameScreen = 'start';
            else if (this.ui.hitTest(lx, ly, this.ui.muteBtn)) this.audio.toggleMute();
        } else if (this.gameScreen === 'paused') {
            if      (this.ui.hitTest(lx, ly, this.ui.resumeBtn))    { this.gameScreen = 'playing'; this.paused = false; }
            else if (this.ui.hitTest(lx, ly, this.ui.restartBtn))   { this.startGameplay(); }
            else if (this.ui.hitTest(lx, ly, this.ui.pauseMenuBtn)) { this.gameScreen = 'modeselect'; this.paused = false; }
            else if (this.ui.hitTest(lx, ly, this.ui.muteBtn))      this.audio.toggleMute();
        } else if (this.gameScreen === 'gameover') {
            if      (this.ui.hitTest(lx, ly, this.ui.playAgainBtn)) this.startGameplay();
            else if (this.ui.hitTest(lx, ly, this.ui.menuBtn))      { this.gameScreen = 'modeselect'; }
            else if (this.ui.hitTest(lx, ly, this.ui.howToPlayBtn)) this.gameScreen = 'howtoplay';
            else if (this.ui.hitTest(lx, ly, this.ui.muteBtn))      this.audio.toggleMute();
        } else if (this.gameScreen === 'playing') {
            if (this.ui.hitTest(lx, ly, this.ui.muteBtn)) this.audio.toggleMute();
        }
    }

    render() {
        const ctx = this.ctx;
        const W   = this.canvas.width;
        const H   = this.canvas.height;

        ctx.clearRect(0, 0, W, H);

        // Modo DUPLA em gameplay / pause -> renderização em tela dividida 50/50
        if (this.gameMode === GameMode.DUPLA &&
            (this.gameScreen === 'playing' || this.gameScreen === 'paused')) {
            this._renderSplitScreen(W, H);
            return;
        }

        // Modo SOLO / Menus normais
        ctx.save();
        if (this.shakeTimer > 0 && this.gameScreen === 'playing') {
            const mag = Math.min(8, 6 * (this.shakeTimer / 400));
            ctx.translate((Math.random() - 0.5) * 2 * mag, (Math.random() - 0.5) * 2 * mag);
        }

        const groundY = this.player1 ? this.player1.groundY : Math.round(H * 0.82);

        if (this.gameScreen === 'start') {
            this.background.draw(ctx, W, H, groundY);
            this.ui.drawStartScreen(ctx, W, H, this.totalCoins);
            this.ui.drawMuteButton(ctx, W, H, this.audio.isMuted);

        } else if (this.gameScreen === 'modeselect') {
            this.background.draw(ctx, W, H, groundY);
            this.ui.drawModeSelect(ctx, W, H, this.totalCoins);
            this.ui.drawMuteButton(ctx, W, H, this.audio.isMuted);

        } else if (this.gameScreen === 'howtoplay') {
            this.background.draw(ctx, W, H, groundY);
            this.ui.drawHowToPlay(ctx, W, H);
            this.ui.drawMuteButton(ctx, W, H, this.audio.isMuted);

        } else if (this.gameScreen === 'playing' || this.gameScreen === 'paused') {
            this.background.draw(ctx, W, H, groundY);
            for (const p of this.particlePool) p.draw(ctx);
            for (const c of this.coinPool) if (!c.isOffscreen && !c.collectedByP1) c.draw(ctx, groundY);
            for (const p of this.potionPool) if (!p.isOffscreen && p.targetPlayer === 'solo') p.draw(ctx, groundY);
            for (const z of this.zombiePool)   z.draw(ctx);
            if (this.player1 && this.player1.web) this.player1.web.draw(ctx, this.player1);
            if (this.player1) this.player1.draw(ctx, null);

            const p1Alive = this.player1 && this.player1.state !== PlayerState.GAME_OVER;
            this.ui.drawHUD(ctx, W, H, this.score, this.highScore,
                this.currentTier.name, this.tierDisplayTimer,
                this.gameMode, this.player1, this.coinsCollected);
            this.ui.drawMuteButton(ctx, W, H, this.audio.isMuted);
            this.ui.drawCrosshair(ctx, this.input.mouseX, this.input.mouseY, true);

            if (this.gameScreen === 'paused') this.ui.drawPause(ctx, W, H);

        } else if (this.gameScreen === 'gameover') {
            this.background.draw(ctx, W, H, groundY);
            if (this.player1) this.player1.draw(ctx, null);
            for (const z of this.zombiePool) z.draw(ctx);
            this.ui.drawGameOver(ctx, W, H, this.score, this.highScore,
                this.gameMode, this.p1ScoreAtDeath, this.p2ScoreAtDeath,
                this.coinsCollected, this.p1Coins, this.p2Coins, this.totalCoins);
            this.ui.drawMuteButton(ctx, W, H, this.audio.isMuted);
        }

        ctx.restore();
    }

    // ---- Renderização modo DUPLA (Split-Screen 50/50 em 100% de largura) ----
    _renderSplitScreen(W, H) {
        const ctx   = this.ctx;
        const HUD_H = Math.max(26, Math.min(34, Math.round(H * 0.045)));
        const halfH = Math.floor(H / 2);
        const sceneH = halfH - HUD_H;
        const groundY = sceneH - 35;

        // Limpa tela inteira
        ctx.fillStyle = '#060614';
        ctx.fillRect(0, 0, W, H);

        const drawHalf = (topY, player, label, isTop) => {
            const sceneTop = topY + HUD_H;
            const midY = topY + HUD_H / 2;
            const fs   = Math.max(11, Math.round(HUD_H * 0.46));

            // Barra de HUD para esta metade
            ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
            ctx.fillRect(0, topY, W, HUD_H);

            ctx.save();
            ctx.textBaseline = 'middle';

            // Nome P1 / P2 à esquerda
            ctx.textAlign = 'left';
            ctx.font = `bold ${fs}px sans-serif`;
            const isP1 = label === 'P1';
            const isActive = player && !player.isEliminated;
            ctx.fillStyle = isActive ? (isP1 ? '#ef5350' : '#ffd54f') : '#777777';
            ctx.fillText(isP1 ? '🕷️ P1 (WASD)' : '🕷️ P2 (SETAS)', 12, midY);

            // Contador de moedas individual do jogador
            const playerCoins = isP1 ? this.p1Coins : this.p2Coins;
            ctx.fillStyle = '#ffd700';
            ctx.font = `bold ${fs}px monospace`;
            ctx.fillText(`🪙 ${String(playerCoins).padStart(3, '0')}`, Math.min(145, W * 0.22), midY);

            // Indicador de Transformação Venom (x2) se ativo para o jogador
            if (player && player.isVenom) {
                ctx.fillStyle = '#e1bee7';
                ctx.font = `bold ${fs}px sans-serif`;
                ctx.fillText('⚡ VENOM (x2)', Math.min(235, W * 0.35), midY);
            }

            // Pontos ao centro
            ctx.textAlign = 'center';
            ctx.fillStyle = '#ffcc44';
            ctx.font = `bold ${fs}px monospace`;
            ctx.fillText(`PONTOS: ${String(this.score).padStart(6, '0')}`, W / 2, midY);

            // Vidas à direita (deixando espaço livre para o ícone de som na metade superior)
            ctx.textAlign = 'right';
            ctx.font = `${fs}px sans-serif`;
            const lv = player ? player.lives : 0;
            let ht = '';
            for (let k = 0; k < 3; k++) ht += (k < lv) ? '❤️' : '🖤';
            const heartsX = isTop ? (W - 55) : (W - 14);
            ctx.fillText(ht, heartsX, midY);
            ctx.restore();

            // Cenário e Ação (Clip exato para cada metade)
            ctx.save();
            ctx.beginPath();
            ctx.rect(0, sceneTop, W, sceneH);
            ctx.clip();

            if (this.shakeTimer > 0) {
                const mag = Math.min(4, 3 * (this.shakeTimer / 400));
                ctx.translate((Math.random() - 0.5) * 2 * mag, (Math.random() - 0.5) * 2 * mag);
            }

            ctx.translate(0, sceneTop);

            // Atualiza groundY do jogador e desenha cenário completo preenchendo 100% da largura
            if (player) player.groundY = groundY;
            this.background.draw(ctx, W, sceneH, groundY);

            // Partículas
            for (const p of this.particlePool) {
                if (!p.isDead && (p.half === 'all' || p.half === (isTop ? 'p1' : 'p2'))) {
                    p.draw(ctx);
                }
            }

            // Moedas
            for (const c of this.coinPool) {
                if (!c.isOffscreen && (isTop ? !c.collectedByP1 : !c.collectedByP2)) {
                    c.draw(ctx, groundY);
                }
            }

            // Poções
            const targetTag = isTop ? 'p1' : 'p2';
            for (const p of this.potionPool) {
                if (!p.isOffscreen && p.targetPlayer === targetTag) {
                    p.draw(ctx, groundY);
                }
            }

            // Inimigos
            for (const z of this.zombiePool) {
                z.y = groundY - z.h;
                z.draw(ctx);
            }

            if (player && player.web) player.web.draw(ctx, player);
            if (player) player.draw(ctx, label);

            ctx.restore();
        };

        // Renderiza P1 em cima e P2 embaixo
        drawHalf(0,     this.player1, 'P1', true);
        drawHalf(halfH, this.player2, 'P2', false);

        // Linha divisória central elegante
        ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
        ctx.fillRect(0, halfH - 1, W, 2);

        // Ícone de som fixo no canto superior direito sem sobrepor os corações
        this.ui.drawMuteButton(ctx, W, H, this.audio.isMuted, true);

        if (this.gameScreen === 'paused') {
            this.ui.drawPause(ctx, W, H);
        }
    }
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

window.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('gameCanvas');
    const game   = new Game(canvas);
    game.start();

    window.addEventListener('keydown', (e) => {
        if (e.code === 'Space' && game.gameScreen === 'start') {
            e.preventDefault();
            game.gameScreen = 'modeselect';
        }
        if (e.code === 'Enter' && game.gameScreen === 'modeselect') {
            e.preventDefault();
            game.gameMode = GameMode.SOLO;
            game.startGameplay();
        }
    });
});
